package p01_JarOfT;

public class Vegetable {
}
