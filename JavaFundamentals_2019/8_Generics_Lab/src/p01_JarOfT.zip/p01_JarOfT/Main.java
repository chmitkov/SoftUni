package p01_JarOfT;

public class Main {
    public static void main(String[] args) {
        Jar jar = new Jar();

        jar.add(new Pickle());
        jar.add(new Vegetable());


    }
}
