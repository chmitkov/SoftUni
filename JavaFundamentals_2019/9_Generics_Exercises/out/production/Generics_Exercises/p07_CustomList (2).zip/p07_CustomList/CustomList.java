package p07_CustomList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

public class CustomList<T extends Comparable<T>> {

    private List<T> data;

    public CustomList() {
        this.data = new ArrayList<T>();
    }

    public void add(T element) {
        this.data.add(element);
    }

    public T remove(int index) {
        return this.data.remove(index);
    }

//•	T getMax()
//•	T getMin()

    public boolean contains(T element) {
        for (T el : data) {
            if (el.compareTo(element) == 0) {
                return true;
            }
        }
        return false;
    }

    public void swap(int firstIndex, int secondIndex) {
        T temp = this.data.get(firstIndex);
        this.data.set(firstIndex, this.data.get(secondIndex));
        this.data.set(secondIndex, temp);
    }

    public int countGreaterThan(T element) {
        return this.data.stream()
                .filter(x -> x.compareTo(element) > 0)
                .toArray().length;
    }

    public T getMax() {
        return this.data.stream()
                .max(T::compareTo).get();
    }

    public T getMin() {
        return this.data.stream()
                .min(T::compareTo).get();
    }

    public void forEach(Consumer<T> consumer){
        for (T d : this.data) {
            consumer.accept(d);
        }
    }

    public void sort(){
        Sorter.sort(this.data);
    }

}
