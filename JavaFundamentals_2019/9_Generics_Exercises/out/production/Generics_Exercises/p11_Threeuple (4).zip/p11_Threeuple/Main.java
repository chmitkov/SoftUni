package p11_Threeuple;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String[] firstCommands = br.readLine().split("\\s+");
        String[] secondCommands = br.readLine().split("\\s+");
        String[] thirdCommands = br.readLine().split("\\s+");


        List<Treeuple> list = new ArrayList<>();

        list.add(new Treeuple(
                firstCommands[0] + " " + firstCommands[1],
                firstCommands[2], firstCommands[3]));

        list.add(new Treeuple(secondCommands[0],
                Integer.parseInt(secondCommands[1]),
                secondCommands[2] == "not" ? false : true));

        list.add(new Treeuple(thirdCommands[0],
                thirdCommands[1].substring(0, 3), thirdCommands[2]));

        list.forEach(System.out::println);
    }
}

