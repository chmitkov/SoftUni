package companyRoster;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        List<Employee> list = new ArrayList<>();

        int numberOfEmployee = Integer.parseInt(br.readLine());

        while (numberOfEmployee-- > 0) {
            String[] commands = br.readLine().split("\\s+");
            String name = commands[0];
            double salary = Double.parseDouble(commands[1]);
            String position = commands[2];
            String department = commands[3];

            switch (commands.length) {
                case 4:
                    list.add(new Employee(name, salary, position, department));
                    break;
                case 5:
                    if (commands[4].matches("\\d+")) {
                        list.add(new Employee(name, salary, position, department, Integer.parseInt(commands[4])));
                    }else {
                        list.add(new Employee(name, salary, position, department, commands[4]));
                    }
                    break;
                case 6:
                    String email2 = commands[4];
                    int age2 = Integer.parseInt(commands[5]);
                    list.add(new Employee(name, salary, position, department, email2, age2));
                    break;
            }

        }

        list.stream().collect(Collectors.groupingBy(Employee::getDepartment))
                .entrySet()
                .stream()
                .sorted((e1,e2)->Double.compare(
                        e2.getValue().stream().mapToDouble(Employee::getSalary).average().getAsDouble(),
                        e1.getValue().stream().mapToDouble(Employee::getSalary).average().getAsDouble()
                ))
                .limit(1)
                .forEach(d->{
                    StringBuilder sb = new StringBuilder();
                    sb.append(String.format("Highest Average Salary: %s%n",d.getKey()));
                    d.getValue()
                            .stream()
                            .sorted(Comparator.comparing(Employee::getSalary,Comparator.reverseOrder()))
                            .forEach(x->{
                        sb.append(String.format("%s %.2f %s %s%n",
                                x.getName(),x.getSalary(),x.getEmail(),x.getAge()));
                    });
                    System.out.println(sb);
                });

    }
}
