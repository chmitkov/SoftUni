package p02_services;

public interface NotificationService {
    boolean isActive();

    void notificationService();
}
