package p02_services;

public class EmailNotificationService extends BaseNotificationService {


    public EmailNotificationService(boolean isActive) {
        super(isActive);
    }
}
