package p02_services;

public class SmsNotificationService extends BaseNotificationService {

    public SmsNotificationService(boolean isActive) {
        super(isActive);
    }
}
