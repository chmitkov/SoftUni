package p03_employee_info;

public class ConsoleClient {
        private Formatter formatter;
        private InfoProvider infoProvider;
}
