package p03_employee_info;

public interface Formatter {
    String format(Iterable<Employee> employees);
}
