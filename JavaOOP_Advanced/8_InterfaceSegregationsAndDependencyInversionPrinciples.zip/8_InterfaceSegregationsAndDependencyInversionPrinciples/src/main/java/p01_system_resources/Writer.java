package p01_system_resources;

public interface Writer {
    void write(String str);
}
