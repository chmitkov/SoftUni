package p04_recharge;

public interface Rechargeable {

    void recharge();
}
