package p04_recharge;

public interface Sleeper {

    void sleep();
}
