package p04_recharge;

public class Main {
    public static void main(String[] args) {
        RechargeStation rechargeStation = new RechargeStation();

        rechargeStation.recharge(new Robot("Robot 1",12));

        
    }
}
