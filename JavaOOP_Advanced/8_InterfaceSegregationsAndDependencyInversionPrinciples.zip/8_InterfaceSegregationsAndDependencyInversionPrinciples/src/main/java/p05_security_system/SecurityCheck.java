package p05_security_system;

public interface SecurityCheck {

    public abstract boolean validateUser();
}
