package p05_security_system;

public interface SecurityUI {

    String requestKeyCard();

    int requestPinCode();
}
