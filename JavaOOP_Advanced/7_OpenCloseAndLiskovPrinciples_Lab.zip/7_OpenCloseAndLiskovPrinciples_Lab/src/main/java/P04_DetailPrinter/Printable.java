package P04_DetailPrinter;

public interface Printable {
    void print();
}
