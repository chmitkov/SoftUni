package P04_DetailPrinter;

public class Developer extends Employee {

    public Developer(String name) {
        super(name);
    }
}
