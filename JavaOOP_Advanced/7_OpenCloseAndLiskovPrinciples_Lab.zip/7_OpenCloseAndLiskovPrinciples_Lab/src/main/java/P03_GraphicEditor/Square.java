package P03_GraphicEditor;

public class Square extends Shape {
}
