package P03_GraphicEditor;

public class GraphicEditor {
    public void drawShape(Shape shape) {
        shape.print();
    }
}
