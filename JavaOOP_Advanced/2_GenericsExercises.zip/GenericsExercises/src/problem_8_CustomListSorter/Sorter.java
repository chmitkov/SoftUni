package problem_8_CustomListSorter;


import java.util.Collections;

public class Sorter {
    public static <T extends Comparable<T>> void sort(CustomList<T> customList) {
        //ToDo
    }

}
