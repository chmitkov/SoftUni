package funportal.web;

public class GlobalConstants {
    public static final String VIEW_MODEL_OBJECT_NAME = "viewModel";

    public static final String SHOPPING_CART_NAME = "shopping-cart";
}
