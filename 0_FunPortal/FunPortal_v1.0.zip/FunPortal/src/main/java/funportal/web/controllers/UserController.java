package funportal.web.controllers;

import funportal.domain.models.binding.UserRegisterBindingModel;
import funportal.domain.models.service.UserServiceModel;
import funportal.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Validator;

@Controller
@RequestMapping("/users")
public class UserController extends BaseController {

    private final UserService userService;
    private final ModelMapper modelMapper;
    private final Validator validator;

    @Autowired
    public UserController(UserService userService, ModelMapper modelMapper, Validator validator) {
        this.userService = userService;
        this.modelMapper = modelMapper;
        this.validator = validator;
    }

    @GetMapping("/register")
    public ModelAndView register() {
        return view("register");
    }

    @PostMapping("/register")
    public ModelAndView registerConfirm(@ModelAttribute(name = "model")
                                                UserRegisterBindingModel model) {

        if (!this.validateBindingModel(model)) {
           return view("register");
        }

        UserServiceModel userServiceModel = this.modelMapper
                .map(model, UserServiceModel.class);

        this.userService.registerUser(userServiceModel);

        return redirect("/home");
    }


    @GetMapping("/login")
    public ModelAndView login() {
        return view("login");
    }

    private boolean validateBindingModel(UserRegisterBindingModel model) {
        return this.validator.validate(model).size() == 0;
    }
}
