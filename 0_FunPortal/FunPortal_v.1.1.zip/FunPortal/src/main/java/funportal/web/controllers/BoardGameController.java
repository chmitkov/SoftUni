package funportal.web.controllers;

import funportal.domain.models.binding.BoardGameBindingModel;
import funportal.domain.models.service.BoardGameServiceModel;
import funportal.domain.models.view.boardGame.BoardGameAllViewModel;
import funportal.domain.models.view.boardGame.BoardGameDeleteViewModel;
import funportal.domain.models.view.boardGame.BoardGameDetailsViewModel;
import funportal.domain.models.view.boardGame.BoardGameEditViewModel;
import funportal.error.BoardGameNotFoundException;
import funportal.service.BoardGameService;
import funportal.service.CloudinaryService;
import funportal.validation.BoardGameValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.naming.directory.InvalidAttributesException;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/boardGames")
public class BoardGameController extends BaseController {

    private final BoardGameService boardGameService;
    private final ModelMapper modelMapper;
    private final CloudinaryService cloudinaryService;
    private final BoardGameValidation boardGameValidation;

    @Autowired
    public BoardGameController(BoardGameService boardGameService, ModelMapper modelMapper, CloudinaryService cloudinaryService, BoardGameValidation boardGameValidation) {
        this.boardGameService = boardGameService;
        this.modelMapper = modelMapper;
        this.cloudinaryService = cloudinaryService;
        this.boardGameValidation = boardGameValidation;
    }

    @GetMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addBoardGame() {
        return view("boardGame/add-board-game");
    }

    @PostMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addBoardGameConfirm(@ModelAttribute(name = "model") BoardGameBindingModel model,
                                            ModelAndView modelAndView) throws IOException, InvalidAttributesException {

        if (!this.boardGameValidation.isValid(model)) {
            return view("boardGame/add-board-game");
        }

        BoardGameServiceModel boardGameServiceModel = this.modelMapper
                .map(model, BoardGameServiceModel.class);

        boardGameServiceModel.setTitleImage(
                this.cloudinaryService.uploadImage(model.getTitleImage()));

        boardGameServiceModel.setBoardImage(
                this.cloudinaryService.uploadImage(model.getBoardImage()));

        this.boardGameService.addBoardGame(boardGameServiceModel);

        return redirect("/boardGames/all");
    }

    @GetMapping("/all")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView allBoardGames(ModelAndView modelAndView) {
        List<BoardGameAllViewModel> games = this.boardGameService
                .findAllBoardGames()
                .stream()
                .map(bg -> this.modelMapper.map(bg, BoardGameAllViewModel.class))
                .collect(Collectors.toList());

        modelAndView.addObject("games", games);

        return view("boardGame/all-board-games", modelAndView);
    }

    @GetMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView deleteBoardGame(@PathVariable String id, ModelAndView modelAndView) throws BoardGameNotFoundException {
        BoardGameDeleteViewModel model = this.modelMapper
                .map(this.boardGameService.findById(id), BoardGameDeleteViewModel.class);

        modelAndView.addObject("model", model);

        return view("boardGame/delete-board-game", modelAndView);
    }

    @PostMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView deleteBoardGameConfirm(@PathVariable String id) {
        this.boardGameService
                .removeBoardGame(id);

        return redirect("/boardGames/all");
    }

    @GetMapping("/details/{id}")
    public ModelAndView detailsGame(@PathVariable String id, ModelAndView modelAndView) throws BoardGameNotFoundException {
        BoardGameDetailsViewModel model = this.modelMapper
                .map(this.boardGameService.findById(id), BoardGameDetailsViewModel.class);

        modelAndView.addObject("model", model);

        return view("boardGame/details-board-game", modelAndView);
    }

    @GetMapping("/edit/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView editGame(@PathVariable String id, ModelAndView modelAndView) throws BoardGameNotFoundException {
        BoardGameEditViewModel model = this.modelMapper
                .map(this.boardGameService.findById(id), BoardGameEditViewModel.class);

        modelAndView.addObject("model", model);

        return view("boardGame/edit-board-game", modelAndView);
    }

    @PostMapping("/edit/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView editBoardGameConfirm(@PathVariable String id,
                                             @ModelAttribute(name = "model") BoardGameEditViewModel model) throws BoardGameNotFoundException, InvalidAttributesException {
        BoardGameServiceModel serviceModel = this.modelMapper
                .map(model, BoardGameServiceModel.class);

        this.boardGameService.updateBoardGame(id, serviceModel);

        return redirect("/boardGames/all");
    }
}
