package funportal.service;

import funportal.domain.entities.BoardGame;
import funportal.domain.models.service.BoardGameServiceModel;
import funportal.error.BoardGameNotFoundException;
import funportal.repository.BoardGameRepository;
import funportal.validation.BoardGameValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.naming.directory.InvalidAttributesException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BoardGameServiceImpl implements BoardGameService {

    private final BoardGameRepository boardGameRepository;
    private final ModelMapper modelMapper;
    private final BoardGameValidation boardGameValidation;

    @Autowired
    public BoardGameServiceImpl(BoardGameRepository boardGameRepository, ModelMapper modelMapper, BoardGameValidation boardGameValidation) {
        this.boardGameRepository = boardGameRepository;
        this.modelMapper = modelMapper;
        this.boardGameValidation = boardGameValidation;
    }

    @Override
    public void addBoardGame(BoardGameServiceModel boardGameServiceModel) throws InvalidAttributesException {

        if(this.boardGameValidation.isValid(boardGameServiceModel)){
            throw new InvalidAttributesException();
        }

        BoardGame boardGame = this.modelMapper
                .map(boardGameServiceModel, BoardGame.class);

        this.boardGameRepository.save(boardGame);
    }

    @Override
    public List<BoardGameServiceModel> findAllBoardGames() {
        return this.boardGameRepository
                .findAll()
                .stream()
                .map(bg -> this.modelMapper.map(bg, BoardGameServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public BoardGameServiceModel findById(String id) throws BoardGameNotFoundException {
        return this.boardGameRepository
                .findById(id)
                .map(bg -> this.modelMapper.map(bg, BoardGameServiceModel.class))
                .orElseThrow(BoardGameNotFoundException::new);
    }

    @Override
    public void removeBoardGame(String id) {
        this.boardGameRepository
                .deleteById(id);
    }

    @Override
    public void updateBoardGame(String id, BoardGameServiceModel boardGameServiceModel) throws BoardGameNotFoundException, InvalidAttributesException {


        if(this.boardGameValidation.isValid(boardGameServiceModel)){
            throw new InvalidAttributesException();
        }

        BoardGame boardGame = this
                .boardGameRepository
                .findById(id)
                .orElseThrow(BoardGameNotFoundException::new);

        boardGame.setName(boardGameServiceModel.getName());
        boardGame.setDescription(boardGameServiceModel.getDescription());

        this.boardGameRepository
                .save(boardGame);
    }
}
