package funportal.validation.implementation;

import funportal.domain.entities.User;
import funportal.domain.models.binding.UserRegisterBindingModel;
import funportal.validation.UserValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Validator;

@Component
public class UserValidationImpl implements UserValidation {

    private final Validator validator;

    @Autowired
    public UserValidationImpl(Validator validator) {
        this.validator = validator;
    }


    @Override
    public boolean isValid(UserRegisterBindingModel userRegisterBindingModel) {
        return this.validator
                .validate(userRegisterBindingModel).size() == 0;
    }

    @Override
    public boolean isValid(User user) {
        return true;
    }
}
