package funportal.validation.implementation;

import funportal.domain.models.binding.BoardGameBindingModel;
import funportal.domain.models.service.BoardGameServiceModel;
import funportal.validation.BoardGameValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Validator;

@Component
public class BoardGameValidationImpl implements BoardGameValidation {

    private final Validator validator;

    @Autowired
    public BoardGameValidationImpl(Validator validator) {
        this.validator = validator;
    }

    @Override
    public boolean isValid(BoardGameBindingModel boardGameBindingModel) {
        return this.validator.validate(boardGameBindingModel).size() == 0
                && boardGameBindingModel.getTitleImage() != null;
    }

    @Override
    public boolean isValid(BoardGameServiceModel boardGameServiceModel) {
        return this.validator.validate(boardGameServiceModel).size() != 0;
    }
}
