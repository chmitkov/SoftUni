package funportal.domain.models.binding;

public class OrigamiStepBindingModel {
    private String imageUrl;
    private String description;

    public OrigamiStepBindingModel() {
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
