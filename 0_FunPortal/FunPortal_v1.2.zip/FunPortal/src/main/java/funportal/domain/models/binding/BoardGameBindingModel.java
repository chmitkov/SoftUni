package funportal.domain.models.binding;

import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class BoardGameBindingModel {

    private String name;
    private String description;
    private MultipartFile titleImage;
    private MultipartFile boardImage;

    public BoardGameBindingModel() {
    }

    @NotEmpty
    @Size(min = 2)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @NotEmpty
    @Size(min = 2)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public MultipartFile getTitleImage() {
        return titleImage;
    }

    public void setTitleImage(MultipartFile titleImage) {
        this.titleImage = titleImage;
    }

    public MultipartFile getBoardImage() {
        return boardImage;
    }

    public void setBoardImage(MultipartFile boardImage) {
        this.boardImage = boardImage;
    }
}
