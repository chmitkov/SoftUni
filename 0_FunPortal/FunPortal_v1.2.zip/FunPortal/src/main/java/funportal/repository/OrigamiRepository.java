package funportal.repository;

import funportal.domain.entities.Origami;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrigamiRepository extends JpaRepository<Origami, String> {
    List<Origami> findAllByOrderByAddedOnDesc();
}
