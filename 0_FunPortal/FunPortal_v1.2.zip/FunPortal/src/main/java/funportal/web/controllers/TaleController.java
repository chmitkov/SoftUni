package funportal.web.controllers;

import funportal.domain.models.binding.TaleBindingModel;
import funportal.domain.models.service.TaleServiceModel;
import funportal.service.CloudinaryService;
import funportal.service.TaleService;
import funportal.validation.TaleValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;

@Controller
@RequestMapping("/tales")
public class TaleController extends BaseController{

    private final TaleService taleService;
    private final ModelMapper modelMapper;
    private final TaleValidation taleValidation;
    private final CloudinaryService cloudinaryService;

    @Autowired
    public TaleController(TaleService taleService, ModelMapper modelMapper, TaleValidation taleValidation, CloudinaryService cloudinaryService) {
        this.taleService = taleService;
        this.modelMapper = modelMapper;
        this.taleValidation = taleValidation;
        this.cloudinaryService = cloudinaryService;
    }

    @GetMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addTale(){
        return view("tale/add-tale");
    }

    @PostMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addTaleConfirm(@ModelAttribute(name = "model")TaleBindingModel model) throws IOException {
        TaleServiceModel serviceModel = this.modelMapper
                .map(model, TaleServiceModel.class);

        serviceModel.setTitleImage(this.cloudinaryService.uploadImage(model.getTitleImage()));

        serviceModel.setAudioUrl(this.cloudinaryService.uploadAudio(model.getAudioUrl()));

        this.taleService
                .saveTale(serviceModel);

        return view("/home");
    }
}
