package funportal.error;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "Board game was not found!")
public class BoardGameNotFoundException extends Throwable {

    private int statusCode;

    public BoardGameNotFoundException() {
        setStatusCode(404);
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }
}
