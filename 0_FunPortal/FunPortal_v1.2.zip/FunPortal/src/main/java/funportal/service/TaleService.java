package funportal.service;

import funportal.domain.models.service.TaleServiceModel;

public interface TaleService {

    void saveTale(TaleServiceModel taleServiceModel);
}
