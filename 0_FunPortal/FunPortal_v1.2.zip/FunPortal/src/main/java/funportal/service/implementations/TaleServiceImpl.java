package funportal.service.implementations;

import funportal.domain.entities.Tale;
import funportal.domain.models.service.TaleServiceModel;
import funportal.repository.TaleRepository;
import funportal.service.TaleService;
import funportal.validation.TaleValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TaleServiceImpl implements TaleService {

    private final TaleRepository taleRepository;
    private final ModelMapper modelMapper;
    private final TaleValidation taleValidation;

    @Autowired
    public TaleServiceImpl(TaleRepository taleRepository, ModelMapper modelMapper, TaleValidation taleValidation) {
        this.taleRepository = taleRepository;
        this.modelMapper = modelMapper;
        this.taleValidation = taleValidation;
    }

    @Override
    public void saveTale(TaleServiceModel taleServiceModel) {
        if (!this.taleValidation.isValid(taleServiceModel)) {
            return;
        }

        Tale tale = this.modelMapper.map(taleServiceModel, Tale.class);

        this.taleRepository.save(tale);
    }
}
