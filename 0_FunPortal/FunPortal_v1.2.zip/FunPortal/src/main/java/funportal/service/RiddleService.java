package funportal.service;

public interface RiddleService {
}
