package funportal.service.implementations;

import funportal.service.RiddleService;
import org.springframework.stereotype.Service;

@Service
public class RiddleServiceImpl implements RiddleService {

}
