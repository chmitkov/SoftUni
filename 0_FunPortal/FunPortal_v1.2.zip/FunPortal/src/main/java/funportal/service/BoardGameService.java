package funportal.service;

import funportal.domain.models.service.BoardGameServiceModel;
import funportal.error.BoardGameNotFoundException;

import javax.naming.directory.InvalidAttributesException;
import java.util.List;

public interface BoardGameService {
    void addBoardGame(BoardGameServiceModel boardGameServiceModel) throws InvalidAttributesException;

    List<BoardGameServiceModel> findAllBoardGames();

    BoardGameServiceModel findById(String id) throws BoardGameNotFoundException;

    void removeBoardGame(String id);

    void updateBoardGame(String id, BoardGameServiceModel boardGameServiceModel) throws BoardGameNotFoundException, InvalidAttributesException;
}
