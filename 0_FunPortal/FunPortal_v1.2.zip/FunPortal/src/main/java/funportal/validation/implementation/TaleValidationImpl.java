package funportal.validation.implementation;

import funportal.domain.models.binding.TaleBindingModel;
import funportal.domain.models.service.TaleServiceModel;
import funportal.validation.TaleValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Validator;

@Component
public class TaleValidationImpl implements TaleValidation {

    private final Validator validator;

    @Autowired
    public TaleValidationImpl(Validator validator) {
        this.validator = validator;
    }

    @Override
    public boolean isValid(TaleBindingModel taleBindingModel) {
        return this.validator.validate(taleBindingModel).size() == 0;

    }

    @Override
    public boolean isValid(TaleServiceModel taleServiceModel) {
        return this.validator.validate(taleServiceModel).size() != 0;
    }
}
