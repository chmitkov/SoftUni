package funportal.validation.implementation;

import funportal.domain.models.binding.OrigamiBindingModel;
import funportal.domain.models.service.OrigamiServiceModel;
import funportal.validation.OrigamiValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Validator;

@Component
public class OrigamiValidationImpl implements OrigamiValidation {

    private final Validator validator;

    @Autowired
    public OrigamiValidationImpl(Validator validator) {
        this.validator = validator;
    }


    @Override
    public boolean isValid(OrigamiBindingModel origamiBindingModel) {
        return this.validator.validate(origamiBindingModel).size() == 0;
    }

    @Override
    public boolean isValid(OrigamiServiceModel origamiServiceModel) {
        return this.validator.validate(origamiServiceModel).size() == 0;
    }
}
