package funportal.validation;

import funportal.domain.models.binding.SongBindingModel;
import funportal.domain.models.service.SongServiceModel;

public interface SongValidation {

    boolean isValid(SongBindingModel songBindingModel);

    boolean isValid(SongServiceModel songServiceModel);
}
