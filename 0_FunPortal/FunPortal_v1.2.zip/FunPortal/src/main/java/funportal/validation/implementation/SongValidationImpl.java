package funportal.validation.implementation;

import funportal.domain.models.binding.SongBindingModel;
import funportal.domain.models.service.SongServiceModel;
import funportal.validation.SongValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Validator;

@Component
public class SongValidationImpl implements SongValidation {

    private final Validator validator;

    @Autowired
    public SongValidationImpl(Validator validator) {
        this.validator = validator;
    }


    @Override
    public boolean isValid(SongBindingModel songBindingModel) {
        return this.validator.validate(songBindingModel).size() == 0;
    }

    @Override
    public boolean isValid(SongServiceModel songServiceModel) {
        return this.validator.validate(songServiceModel).size() == 0;
    }
}
