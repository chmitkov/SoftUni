package funportal.validation;

import funportal.domain.models.binding.BoardGameBindingModel;
import funportal.domain.models.service.BoardGameServiceModel;

public interface BoardGameValidation {
    boolean isValid(BoardGameBindingModel boardGameBindingModel);
    boolean isValid(BoardGameServiceModel boardGameServiceModel);
}
