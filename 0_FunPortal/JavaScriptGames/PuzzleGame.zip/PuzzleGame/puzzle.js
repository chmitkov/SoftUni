const puzzleElement = document.getElementById('puzzle');

let imgArray = ["/img/image_part_001.jpg", "/img/image_part_002.jpg", "/img/image_part_003.jpg", "/img/image_part_004.jpg", "/img/image_part_005.jpg",
    "/img/image_part_006.jpg", "/img/image_part_007.jpg", "/img/image_part_008.jpg", "/img/image_part_009.jpg", "/img/image_part_010.jpg",
    "/img/image_part_011.jpg", "/img/image_part_012.jpg", "/img/image_part_013.jpg", "/img/image_part_014.jpg", "/img/image_part_015.jpg"]
    .map((x, i) => [x, i, Math.random()])
    .sort((a, b) => a[2] - b[2]);



for (let i = 0; i < imgArray.length; i++) {
    let pictureElement = document.createElement('img');

    pictureElement.src = imgArray[i][0];
    pictureElement.place = imgArray[i][1];
    pictureElement.className = 'puzzleImg'
    pictureElement.clicked = false;

    puzzleElement.appendChild(pictureElement);
}

let step = 1;
let pictureOne;
let pictureTwo;

const changePlaces = function () {
    let tempPlace = pictureTwo.place;
    let tempSrc = pictureTwo.src;

    pictureTwo.place = pictureOne.place;
    pictureTwo.src = pictureOne.src;

    pictureOne.place = tempPlace;
    pictureOne.src = tempSrc;
}

const clearFields = function () {
    pictureOne = null;
    pictureTwo = null;
}

const isPlayerWin = function () {
    let isWin = true;
    let allParts = puzzleElement.children;

    console.log(allParts);
    for (let i = 0; i < allParts.length; i++) {
        if (allParts[i].place != i) {
            isWin = false;
            break;
        }
    }

    return isWin;
}

document.addEventListener('click', function (e) {
    switch (step) {
        case 1:
            if (e.target.tagName === 'IMG' && e.target.clicked == false) {
                e.target.className = 'select';
                e.clicked = true;
                pictureOne = e.target;
                step = 2;
            }
            break;

        case 2:
            if (e.target.tagName === 'IMG' && e.target.clicked == false) {
                e.target.className = 'select';
                e.clicked = true;
                pictureTwo = e.target;

                step = 1;
                changePlaces();
                clearFields;

                if (isPlayerWin()) {
                    let h1 = document.createElement('h1');
                    h1.textContent = '<h1>You win!</h1>';
                    document.body.prepend(h1);
                }
            }
            break;
    };
});
