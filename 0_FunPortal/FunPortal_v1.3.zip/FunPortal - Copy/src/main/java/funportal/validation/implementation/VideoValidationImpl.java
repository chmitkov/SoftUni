package funportal.validation.implementation;

import funportal.domain.models.binding.VideoBindingModel;
import funportal.domain.models.service.VideoServiceModel;
import funportal.validation.VideoValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Validator;

@Component
public class VideoValidationImpl implements VideoValidation {

    private final Validator validator;

    @Autowired
    public VideoValidationImpl(Validator validator) {
        this.validator = validator;
    }

    @Override
    public boolean isValid(VideoBindingModel videoBindingModel) {
        return this.validator.validate(videoBindingModel).size() == 0;
    }

    @Override
    public boolean isValid(VideoServiceModel videoServiceModel) {
        return this.validator.validate(videoServiceModel).size() == 0;
    }
}
