package funportal.validation;

import funportal.domain.models.binding.OrigamiBindingModel;
import funportal.domain.models.service.OrigamiServiceModel;

public interface OrigamiValidation {
    boolean isValid(OrigamiBindingModel origamiBindingModel);

    boolean isValid(OrigamiServiceModel origamiServiceModel);
}
