package funportal.domain.entities;

import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users")
public class User extends BaseEntity implements UserDetails {

    private String username;
    private String password;
    private String email;
    private String imageUrl;
    private Set<Role> authorities;
    private Set<Video> favouriteVideos;
    private Set<Article> favouriteArticles;
    private Set<Article> myArticles;
    private Set<Comment> myComments;
    private LocalDateTime registeredOn;

    public User() {
//        this.setFavouriteVideos(new HashSet<>());
//        this.setFavouriteArticles(new HashSet<>());
    }

    @Override
    @Column(name = "username", nullable = false, unique = true, updatable = false)
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    @Column(name = "password", nullable = false)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Column(name = "email", nullable = false)
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    @ManyToMany(targetEntity = Role.class, fetch = FetchType.EAGER)
    @JoinTable(
            name = "users_roles",
            joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id")
    )
    public Set<Role> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(Set<Role> authorities) {
        this.authorities = authorities;
    }

    @ManyToMany(targetEntity = Video.class, fetch = FetchType.EAGER)
    @JoinTable(name = "users_videos",
            joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "video_id", referencedColumnName = "id")
    )
    public Set<Video> getFavouriteVideos() {
        return favouriteVideos;
    }

    public void setFavouriteVideos(Set<Video> favouriteVideos) {
        this.favouriteVideos = favouriteVideos;
    }

    @ManyToMany(targetEntity = Article.class, fetch = FetchType.EAGER)
    @JoinTable(name = "users_articles",
            joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "article_id", referencedColumnName = "id")
    )
    public Set<Article> getFavouriteArticles() {
        return favouriteArticles;
    }

    public void setFavouriteArticles(Set<Article> favouriteArticles) {
        this.favouriteArticles = favouriteArticles;
    }

    @Column(name = "image_url")
    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @OneToMany(mappedBy = "author", targetEntity = Article.class,
            fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    public Set<Article> getMyArticles() {
        return myArticles;
    }

    public void setMyArticles(Set<Article> myArticles) {
        this.myArticles = myArticles;
    }

    @Column(name = "registered_on", nullable = false)
    public LocalDateTime getRegisteredOn() {
        return registeredOn;
    }

    public void setRegisteredOn(LocalDateTime registeredOn) {
        this.registeredOn = registeredOn;
    }

    @OneToMany(mappedBy = "author", targetEntity = Comment.class,
            fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    public Set<Comment> getMyComments() {
        return myComments;
    }

    public void setMyComments(Set<Comment> myComments) {
        this.myComments = myComments;
    }

    @Override
    @Transient
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    @Transient
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    @Transient
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    @Transient
    public boolean isEnabled() {
        return true;
    }
}
