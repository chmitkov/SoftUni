package funportal.domain.models.binding;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class SongBindingModel {

    private String name;
    private String description;
    private String url;

    public SongBindingModel() {
    }

    @NotNull
    @Size(min = 2)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    @Size(min = 2)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @NotNull
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
