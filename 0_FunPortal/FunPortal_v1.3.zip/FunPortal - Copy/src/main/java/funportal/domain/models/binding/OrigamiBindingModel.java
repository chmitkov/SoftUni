package funportal.domain.models.binding;

import org.springframework.lang.NonNull;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

public class OrigamiBindingModel {
    private String name;
    private MultipartFile titleImage;
    private String description;
    private String videoUrl;
    private MultipartFile step1;
    private MultipartFile step2;
    private MultipartFile step3;
    private MultipartFile step4;
    private MultipartFile step5;
    private String stepDescription1;
    private String stepDescription2;
    private String stepDescription3;
    private String stepDescription4;
    private String stepDescription5;

    public OrigamiBindingModel() {
    }

    @NonNull
    @NotEmpty
    @Size(min = 2)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    public MultipartFile getTitleImage() {
        return titleImage;
    }

    public void setTitleImage(MultipartFile titleImage) {
        this.titleImage = titleImage;
    }

    @NonNull
    @NotEmpty
    @Size(min = 2)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public MultipartFile getStep1() {
        return step1;
    }

    public void setStep1(MultipartFile step1) {
        this.step1 = step1;
    }

    public MultipartFile getStep2() {
        return step2;
    }

    public void setStep2(MultipartFile step2) {
        this.step2 = step2;
    }

    public MultipartFile getStep3() {
        return step3;
    }

    public void setStep3(MultipartFile step3) {
        this.step3 = step3;
    }

    public MultipartFile getStep4() {
        return step4;
    }

    public void setStep4(MultipartFile step4) {
        this.step4 = step4;
    }

    public MultipartFile getStep5() {
        return step5;
    }

    public void setStep5(MultipartFile step5) {
        this.step5 = step5;
    }

    public String getStepDescription1() {
        return stepDescription1;
    }

    public void setStepDescription1(String stepDescription1) {
        this.stepDescription1 = stepDescription1;
    }

    public String getStepDescription2() {
        return stepDescription2;
    }

    public void setStepDescription2(String stepDescription2) {
        this.stepDescription2 = stepDescription2;
    }

    public String getStepDescription3() {
        return stepDescription3;
    }

    public void setStepDescription3(String stepDescription3) {
        this.stepDescription3 = stepDescription3;
    }

    public String getStepDescription4() {
        return stepDescription4;
    }

    public void setStepDescription4(String stepDescription4) {
        this.stepDescription4 = stepDescription4;
    }

    public String getStepDescription5() {
        return stepDescription5;
    }

    public void setStepDescription5(String stepDescription5) {
        this.stepDescription5 = stepDescription5;
    }
}
