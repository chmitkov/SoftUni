package funportal.domain.models.service;

import java.time.LocalDateTime;

public class CommentServiceModel extends BaseServiceModel{
    private UserServiceModel author;
    private ArticleServiceModel article;
    private LocalDateTime addedOn;
    private String textContent;

    public CommentServiceModel() {
    }

    public UserServiceModel getAuthor() {
        return author;
    }

    public void setAuthor(UserServiceModel author) {
        this.author = author;
    }

    public ArticleServiceModel getArticle() {
        return article;
    }

    public void setArticle(ArticleServiceModel article) {
        this.article = article;
    }

    public LocalDateTime getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(LocalDateTime addedOn) {
        this.addedOn = addedOn;
    }

    public String getTextContent() {
        return textContent;
    }

    public void setTextContent(String textContent) {
        this.textContent = textContent;
    }
}
