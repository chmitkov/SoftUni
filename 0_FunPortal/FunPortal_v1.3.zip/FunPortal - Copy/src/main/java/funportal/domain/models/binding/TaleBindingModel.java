package funportal.domain.models.binding;

import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class TaleBindingModel {
    private String name;
    private MultipartFile audioUrl;
    private MultipartFile titleImage;
    private String description;

    public TaleBindingModel() {
    }

    @NotNull
    @NotEmpty
    @Size(min = 2)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public MultipartFile getAudioUrl() {
        return audioUrl;
    }

    public void setAudioUrl(MultipartFile audioUrl) {
        this.audioUrl = audioUrl;
    }

    public MultipartFile getTitleImage() {
        return titleImage;
    }

    public void setTitleImage(MultipartFile titleImage) {
        this.titleImage = titleImage;
    }

    @NotNull
    @NotEmpty
    @Size(min = 1)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
