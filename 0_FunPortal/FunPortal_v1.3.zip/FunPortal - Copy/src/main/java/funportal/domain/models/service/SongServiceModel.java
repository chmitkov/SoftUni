package funportal.domain.models.service;


import org.springframework.lang.NonNull;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

public class SongServiceModel extends BaseServiceModel {

    private String name;
    private String description;
    private String url;
    private LocalDateTime addedOn;

    public SongServiceModel() {
    }
    @NonNull
    @NotEmpty
    @Size(min = 2)
    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }

    @NonNull
    @NotEmpty
    @Size(min = 2)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @NonNull
    @NotEmpty
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public LocalDateTime getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(LocalDateTime addedOn) {
        this.addedOn = addedOn;
    }
}
