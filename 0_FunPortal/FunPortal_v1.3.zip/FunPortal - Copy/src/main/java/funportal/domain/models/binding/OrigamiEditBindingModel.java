package funportal.domain.models.binding;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class OrigamiEditBindingModel {
    private String name;
    private String description;

    public OrigamiEditBindingModel() {
    }

    @NotNull
    @NotNull
    @Size(min = 2)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NotNull
    @NotNull
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
