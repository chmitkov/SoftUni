package funportal.service;

import funportal.domain.models.service.OrigamiServiceModel;
import funportal.error.OrigamiNotFoundException;

import java.util.List;

public interface OrigamiService {
    void addOrigami(OrigamiServiceModel origamiServiceModel);

    List<OrigamiServiceModel> findAllOrderByAddedOn();

    OrigamiServiceModel findById(String id) throws OrigamiNotFoundException;

    void removeOrigamiById(String id);

    void editOrigamiById(String id, OrigamiServiceModel origamiServiceModel) throws OrigamiNotFoundException;
}
