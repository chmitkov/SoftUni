package funportal.service.implementations;

import funportal.domain.entities.Song;
import funportal.domain.models.service.SongServiceModel;
import funportal.error.SongNotFoundException;
import funportal.repository.SongRepository;
import funportal.service.SongService;
import funportal.validation.SongValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SongServiceImpl implements SongService {

    private final SongRepository songRepository;
    private final SongValidation songValidation;
    private final ModelMapper modelMapper;

    @Autowired
    public SongServiceImpl(SongRepository songRepository, SongValidation songValidation, ModelMapper modelMapper) {
        this.songRepository = songRepository;
        this.songValidation = songValidation;
        this.modelMapper = modelMapper;
    }

    @Override
    public void addSong(SongServiceModel songServiceModel) {

        if (!this.songValidation.isValid(songServiceModel)) {
            return;
        }

        songServiceModel.setAddedOn(LocalDateTime.now());

        Song song = this.modelMapper.map(songServiceModel, Song.class);

        this.songRepository.save(song);
    }

    @Override
    public List<SongServiceModel> findAllSongsOrderByAddedOn() {
        return this.songRepository
                .findAllByOrderByAddedOn()
                .stream()
                .map(s -> this.modelMapper.map(s, SongServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public SongServiceModel findById(String id) throws SongNotFoundException {
        return this.songRepository
                .findById(id)
                .map(s-> this.modelMapper.map(s, SongServiceModel.class))
                .orElseThrow(SongNotFoundException::new);
    }

    @Override
    public void removeSongById(String id) {
        this.songRepository
                .deleteById(id);
    }

    @Override
    public void editSong(String id, SongServiceModel songServiceModel) throws SongNotFoundException {
        Song song = this.songRepository
                .findById(id)
                .orElseThrow(SongNotFoundException::new);

        song.setName(songServiceModel.getName());
        song.setDescription(songServiceModel.getDescription());

        this.songRepository.save(song);
    }
}
