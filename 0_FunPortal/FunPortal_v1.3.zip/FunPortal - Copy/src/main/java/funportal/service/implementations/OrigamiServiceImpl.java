package funportal.service.implementations;

import funportal.domain.entities.Origami;
import funportal.domain.entities.OrigamiStep;
import funportal.domain.models.service.OrigamiServiceModel;
import funportal.error.OrigamiNotFoundException;
import funportal.repository.OrigamiRepository;
import funportal.repository.OrigamiStepRepository;
import funportal.service.OrigamiService;
import funportal.validation.OrigamiValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrigamiServiceImpl implements OrigamiService {

    private final OrigamiRepository origamiRepository;
    private final OrigamiStepRepository origamiStepRepository;
    private final OrigamiValidation origamiValidation;
    private final ModelMapper modelMapper;

    @Autowired
    public OrigamiServiceImpl(OrigamiRepository origamiRepository, OrigamiStepRepository origamiStepRepository, OrigamiValidation origamiValidation, ModelMapper modelMapper) {
        this.origamiRepository = origamiRepository;
        this.origamiStepRepository = origamiStepRepository;
        this.origamiValidation = origamiValidation;
        this.modelMapper = modelMapper;
    }

    @Override
    public void addOrigami(OrigamiServiceModel origamiServiceModel) {
        if (!this.origamiValidation.isValid(origamiServiceModel)) {
            return;
        }

        Origami origami = this.modelMapper
                .map(origamiServiceModel, Origami.class);

        List<OrigamiStep> stepList = origamiServiceModel
                .getSteps()
                .stream()
                .map(s -> this.modelMapper.map(s, OrigamiStep.class))
                .collect(Collectors.toList());

        stepList
                .forEach(this.origamiStepRepository::saveAndFlush);

        origami.setSteps(stepList);

        this.origamiRepository.save(origami);
    }

    @Override
    public List<OrigamiServiceModel> findAllOrderByAddedOn() {
        return this.origamiRepository
                .findAllByOrderByAddedOnDesc()
                .stream()
                .map(o -> this.modelMapper.map(o, OrigamiServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public OrigamiServiceModel findById(String id) throws OrigamiNotFoundException {
        return this.origamiRepository
                .findById(id)
                .map(o -> this.modelMapper.map(o, OrigamiServiceModel.class))
                .orElseThrow(OrigamiNotFoundException::new);
    }

    @Override
    public void removeOrigamiById(String id) {
        this.origamiRepository
                .deleteById(id);
    }

    @Override
    public void editOrigamiById(String id, OrigamiServiceModel origamiServiceModel) throws OrigamiNotFoundException {
        if (!this.origamiValidation.isValid(origamiServiceModel)){
            return;
        }

        Origami origami = this.origamiRepository
                .findById(id)
                .orElseThrow(OrigamiNotFoundException::new);

        origami.setName(origamiServiceModel.getName());
        origami.setDescription(origamiServiceModel.getDescription());

        this.origamiRepository.save(origami);
    }
}
