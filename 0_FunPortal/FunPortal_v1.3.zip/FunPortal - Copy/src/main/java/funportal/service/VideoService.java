package funportal.service;

import funportal.domain.models.service.VideoServiceModel;
import funportal.error.VideoNotFoundException;

import java.util.List;

public interface VideoService {
    void addVideo(VideoServiceModel videoServiceModel);

    List<VideoServiceModel> findAllVideosOrderByAddedOn();

    VideoServiceModel findVideoById(String id) throws VideoNotFoundException;

    void likeVideoById(String id, String username) throws VideoNotFoundException;

    void removeVideoById(String id, String username) throws VideoNotFoundException;

    void editVideo(String id, VideoServiceModel videoServiceModel) throws VideoNotFoundException;

    List<VideoServiceModel> findUserFavouriteVideos(String username);
}
