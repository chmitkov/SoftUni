package funportal.service.implementations;

import funportal.domain.entities.Riddle;
import funportal.domain.models.service.RiddleServiceModel;
import funportal.error.RiddleNotFoundException;
import funportal.repository.RiddleRepository;
import funportal.service.RiddleService;
import funportal.validation.RiddleValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RiddleServiceImpl implements RiddleService {

    private final RiddleRepository riddleRepository;
    private final RiddleValidation riddleValidation;
    private final ModelMapper modelMapper;

    @Autowired
    public RiddleServiceImpl(RiddleRepository riddleRepository, RiddleValidation riddleValidation, ModelMapper modelMapper) {
        this.riddleRepository = riddleRepository;
        this.riddleValidation = riddleValidation;
        this.modelMapper = modelMapper;
    }

    @Override
    public void addRiddle(RiddleServiceModel riddleServiceModel) {
        Riddle riddle = this.modelMapper
                .map(riddleServiceModel, Riddle.class);

        riddle.setAddedOn(LocalDateTime.now());

        this.riddleRepository.save(riddle);
    }

    @Override
    public List<RiddleServiceModel> findAllOrderByAddedOn() {
        return this.riddleRepository
                .findAllByOrderByAddedOnDesc()
                .stream()
                .map(r -> this.modelMapper.map(r, RiddleServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public RiddleServiceModel findById(String id) throws RiddleNotFoundException {
        return this.riddleRepository
                .findById(id)
                .map(r -> this.modelMapper.map(r, RiddleServiceModel.class))
                .orElseThrow(RiddleNotFoundException::new);
    }

    @Override
    public void removeById(String id) {
        this.riddleRepository
                .deleteById(id);
    }

    @Override
    public void editRiddle(String id, RiddleServiceModel riddleServiceModel) throws RiddleNotFoundException {
        if (!this.riddleValidation.isValid(riddleServiceModel)) {
            return;
        }

        Riddle riddle = this.riddleRepository
                .findById(id)
                .orElseThrow(RiddleNotFoundException::new);

        riddle.setDescription(riddleServiceModel.getDescription());
        riddle.setAnswer(riddleServiceModel.getAnswer());

        this.riddleRepository.save(riddle);
    }
}
