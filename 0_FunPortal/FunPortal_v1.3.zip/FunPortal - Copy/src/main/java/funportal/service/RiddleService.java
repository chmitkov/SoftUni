package funportal.service;

import funportal.domain.models.service.RiddleServiceModel;
import funportal.error.RiddleNotFoundException;

import java.util.List;

public interface RiddleService {

    void addRiddle(RiddleServiceModel riddleServiceModel);

    List<RiddleServiceModel> findAllOrderByAddedOn();

    RiddleServiceModel findById(String id) throws RiddleNotFoundException;

    void removeById(String id);

    void editRiddle(String id, RiddleServiceModel riddleServiceModel) throws RiddleNotFoundException;
}
