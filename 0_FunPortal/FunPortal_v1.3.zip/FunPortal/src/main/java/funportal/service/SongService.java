package funportal.service;

import funportal.domain.models.service.SongServiceModel;
import funportal.error.SongNotFoundException;

import java.util.List;

public interface SongService {

    void addSong(SongServiceModel songServiceModel);

    List<SongServiceModel> findAllSongsOrderByAddedOn();

    SongServiceModel findById(String id) throws SongNotFoundException;

    void removeSongById(String id);

    void editSong(String id, SongServiceModel songServiceModel) throws SongNotFoundException;
}
