package funportal.service.implementations;

import funportal.domain.entities.User;
import funportal.domain.entities.Video;
import funportal.domain.models.service.UserServiceModel;
import funportal.domain.models.service.VideoServiceModel;
import funportal.domain.models.view.video.VideoAllViewModel;
import funportal.error.VideoNotFoundException;
import funportal.repository.VideoRepository;
import funportal.service.UserService;
import funportal.service.VideoService;
import funportal.validation.VideoValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class VideoServiceImpl implements VideoService {

    private final VideoRepository videoRepository;
    private final UserService userService;
    private final ModelMapper modelMapper;
    private final VideoValidation videoValidation;

    @Autowired
    public VideoServiceImpl(VideoRepository videoRepository, UserService userService, ModelMapper modelMapper, VideoValidation videoValidation) {
        this.videoRepository = videoRepository;
        this.userService = userService;
        this.modelMapper = modelMapper;
        this.videoValidation = videoValidation;
    }

    @Override
    public void addVideo(VideoServiceModel videoServiceModel) {
        if (!this.videoValidation.isValid(videoServiceModel)) {
            return;
        }

        Video video = this.modelMapper.map(videoServiceModel, Video.class);
        video.setAddedOn(LocalDateTime.now());

        this.videoRepository.save(video);
    }

    @Override
    public List<VideoServiceModel> findAllVideosOrderByAddedOn() {
        return this.videoRepository
                .findAllByOrderByAddedOnDesc()
                .stream()
                .map(v -> this.modelMapper.map(v, VideoServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public VideoServiceModel findVideoById(String id) throws VideoNotFoundException {
        return this.videoRepository
                .findById(id)
                .map(v -> this.modelMapper.map(v, VideoServiceModel.class))
                .orElseThrow(VideoNotFoundException::new);
    }

    @Override
    public void likeVideoById(String id, String username) throws VideoNotFoundException {

        UserServiceModel user = this.userService.findUserByUsername(username);
        Video video = null;

        if (user.getFavouriteVideos().stream().anyMatch(x -> x.getId().equals(id))) {
            return;
        } else {
            video = this.videoRepository
                    .findById(id)
                    .orElseThrow(VideoNotFoundException::new);

            video.setLikes(video.getLikes() + 1);
            user.getFavouriteVideos()
                    .add(video);

            userService.saveUser(user);
        }

        videoRepository.saveAndFlush(video);
    }

    @Override
    public void removeVideoById(String id, String username) throws VideoNotFoundException {
        UserServiceModel user = this.userService.findUserByUsername(username);
        Video video = this.videoRepository.findById(id)
                .orElseThrow(VideoNotFoundException::new);

        user.getFavouriteVideos().remove(video);

        this.userService.saveUser(user);
        this.videoRepository.deleteById(id);
    }

    @Override
    public void editVideo(String id, VideoServiceModel videoServiceModel) throws VideoNotFoundException {
        Video video = this.videoRepository.findById(id)
                .orElseThrow(VideoNotFoundException::new);

        video.setName(videoServiceModel.getName());
        video.setDescription(videoServiceModel.getDescription());
        video.setAddedOn(LocalDateTime.now());

        this.videoRepository.save(video);
    }

    @Override
    public List<VideoServiceModel> findUserFavouriteVideos(String username) {
        UserServiceModel user = this.userService.findUserByUsername(username);

        return user
                .getFavouriteVideos()
                .stream()
                .map(v -> this.modelMapper.map(v, VideoServiceModel.class))
                .collect(Collectors.toList());
    }
}
