package funportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FunPortalApplication {

    public static void main(String[] args) {
        SpringApplication.run(FunPortalApplication.class, args);
    }

}
