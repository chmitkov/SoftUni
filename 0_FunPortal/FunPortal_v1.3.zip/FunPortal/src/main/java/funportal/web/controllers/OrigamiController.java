package funportal.web.controllers;

import funportal.domain.models.binding.OrigamiBindingModel;
import funportal.domain.models.binding.OrigamiEditBindingModel;
import funportal.domain.models.binding.OrigamiStepBindingModel;
import funportal.domain.models.service.OrigamiServiceModel;
import funportal.domain.models.service.OrigamiStepServiceModel;
import funportal.domain.models.view.origami.OrigamiAllViewModel;
import funportal.domain.models.view.origami.OrigamiDeleteViewModel;
import funportal.domain.models.view.origami.OrigamiDetailsViewModel;
import funportal.domain.models.view.origami.OrigamiEditViewModel;
import funportal.error.OrigamiNotFoundException;
import funportal.service.CloudinaryService;
import funportal.service.OrigamiService;
import funportal.validation.OrigamiValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Controller
@RequestMapping("/origami")
public class OrigamiController extends BaseController {


    private final OrigamiService origamiService;
    private final OrigamiValidation origamiValidation;
    private final ModelMapper modelMapper;
    private final CloudinaryService cloudinaryService;

    @Autowired
    public OrigamiController(OrigamiService origamiService, OrigamiValidation origamiValidation, ModelMapper modelMapper, CloudinaryService cloudinaryService) {
        this.origamiService = origamiService;
        this.origamiValidation = origamiValidation;
        this.modelMapper = modelMapper;
        this.cloudinaryService = cloudinaryService;
    }

    @GetMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addOrigami() {

        return view("origami/add-origami");
    }

    @PostMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addOrigamiConfirm(@ModelAttribute(name = "model") OrigamiBindingModel model) throws IllegalAccessException, IOException, NoSuchFieldException {

        if (!this.origamiValidation.isValid(model)) {
            return view("origami/add-origami");
        }

        List<OrigamiStepBindingModel> steps = this.buildListOfSteps(model);

        OrigamiServiceModel serviceModel = this.modelMapper.map(model, OrigamiServiceModel.class);
        serviceModel.setTitleImage(this.cloudinaryService.uploadImage(model.getTitleImage()));
        serviceModel.setSteps(steps.stream()
                .map(s -> this.modelMapper
                        .map(s, OrigamiStepServiceModel.class)).collect(Collectors.toList()));
        serviceModel.setAddedOn(LocalDateTime.now());

        this.origamiService.addOrigami(serviceModel);

        return redirect("/origami/all");
    }

    @GetMapping("/all")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView allOrigami(ModelAndView modelAndView) {
        List<OrigamiAllViewModel> allOrigami = this.origamiService
                .findAllOrderByAddedOn()
                .stream()
                .map(o -> this.modelMapper.map(o, OrigamiAllViewModel.class))
                .collect(Collectors.toList());

        modelAndView.addObject("allOrigami", allOrigami);

        return view("origami/all-origami", modelAndView);
    }

    @GetMapping("delete/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView deleteOrigami(@PathVariable String id, ModelAndView modelAndView) throws OrigamiNotFoundException {
        OrigamiDeleteViewModel model = this.modelMapper
                .map(this.origamiService.findById(id), OrigamiDeleteViewModel.class);

        modelAndView.addObject("model", model);

        return view("origami/delete-origami", modelAndView);
    }

    @PostMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView deleteOrigamiConfirm(@PathVariable String id) {
        this.origamiService
                .removeOrigamiById(id);

        return redirect("/origami/all");
    }

    @GetMapping("/details/{id}")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView detailsOrigami(@PathVariable String id, ModelAndView modelAndView) throws OrigamiNotFoundException {
        OrigamiDetailsViewModel model = this.modelMapper
                .map(this.origamiService.findById(id), OrigamiDetailsViewModel.class);

        modelAndView.addObject("model", model);

        return view("origami/details-origami", modelAndView);
    }

    @GetMapping("/edit/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView editOrigami(@PathVariable String id, ModelAndView modelAndView) throws OrigamiNotFoundException {
        OrigamiEditViewModel model = this.modelMapper
                .map(this.origamiService.findById(id), OrigamiEditViewModel.class);

        modelAndView.addObject("model", model);

        return view("origami/edit-origami", modelAndView);
    }

    @PostMapping("/edit/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView editOrigamiConfirm(@PathVariable String id,
                                           @ModelAttribute(name = "model") OrigamiEditBindingModel model) throws OrigamiNotFoundException {

        OrigamiServiceModel serviceModel = this.modelMapper
                .map(model, OrigamiServiceModel.class);
        this.origamiService
                .editOrigamiById(id, serviceModel);

        return redirect("/origami/details/" + id);
    }

    //TODO : Needs to refactor this method
    private List<OrigamiStepBindingModel> buildListOfSteps(OrigamiBindingModel model) throws IllegalAccessException, IOException, NoSuchFieldException {
        Map<MultipartFile, String> mapStepImage = new LinkedHashMap<>();
        List<OrigamiStepBindingModel> list = new ArrayList<>();

        for (Field field : model.getClass().getDeclaredFields()) {
            if (field.getName().startsWith("stepDescription")) {

                field.setAccessible(true);
                if (field.get(model) == null) {
                    continue;
                }

                String step = "step" + field.getName().substring(field.getName().length() - 1);

                Field field1 = model.getClass().getDeclaredField(step);
                field1.setAccessible(true);
                MultipartFile multipartFile = (MultipartFile) field1.get(model);

                mapStepImage.put(multipartFile, (String) field.get(model));
            }
        }

        for (MultipartFile multipartFile : mapStepImage.keySet()) {
            OrigamiStepBindingModel origamiStepBindingModel = new OrigamiStepBindingModel();
            origamiStepBindingModel.setDescription(mapStepImage.get(multipartFile));
            origamiStepBindingModel.setImageUrl(this.cloudinaryService
                    .uploadImage(multipartFile));

            list.add(origamiStepBindingModel);
        }

        return list;

    }


}
