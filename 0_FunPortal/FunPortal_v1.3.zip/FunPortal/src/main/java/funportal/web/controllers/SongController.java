package funportal.web.controllers;

import funportal.domain.models.binding.SongBindingModel;
import funportal.domain.models.binding.SongEditBindingModel;
import funportal.domain.models.service.SongServiceModel;
import funportal.domain.models.view.song.SongAllViewModel;
import funportal.domain.models.view.song.SongDeleteViewModel;
import funportal.domain.models.view.song.SongDetailsViewModel;
import funportal.domain.models.view.song.SongEditViewModel;
import funportal.error.SongNotFoundException;
import funportal.service.SongService;
import funportal.validation.SongValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import static funportal.web.GlobalConstants.VIEW_MODEL_OBJECT_NAME;

@Controller
@RequestMapping("/songs")
public class SongController extends BaseController {

    private final SongService songService;
    private final SongValidation songValidation;
    private final ModelMapper modelMapper;

    @Autowired
    public SongController(SongService songService, SongValidation songValidation, ModelMapper modelMapper) {
        this.songService = songService;
        this.songValidation = songValidation;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addSong() {
        return view("song/add-song");
    }

    @PostMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addSongConfirm(@ModelAttribute(name = "model") SongBindingModel model) {

        if (!this.songValidation.isValid(model)) {
            return redirect("/songs/add");
        }

        SongServiceModel songServiceModel = this.modelMapper
                .map(model, SongServiceModel.class);

        songServiceModel.setAddedOn(LocalDateTime.now());
        this.songService.addSong(songServiceModel);

        return redirect("/songs/all");
    }

    @GetMapping("/all")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView allSongs(ModelAndView modelAndView) {
        List<SongAllViewModel> songs = this.songService
                .findAllSongsOrderByAddedOn()
                .stream()
                .map(s -> this.modelMapper.map(s, SongAllViewModel.class))
                .collect(Collectors.toList());

        modelAndView.addObject("songs", songs);

        return view("song/all-songs", modelAndView);
    }

    @GetMapping("/details/{id}")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView detailsSong(@PathVariable String id, ModelAndView modelAndView) throws SongNotFoundException {
        SongDetailsViewModel model = this.modelMapper
                .map(this.songService.findById(id), SongDetailsViewModel.class);

        modelAndView.addObject(VIEW_MODEL_OBJECT_NAME, model);

        return view("song/details-song", modelAndView);
    }

    @GetMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView deleteSong(@PathVariable String id, ModelAndView modelAndView) throws SongNotFoundException {
        SongDeleteViewModel model = this.modelMapper
                .map(this.songService.findById(id), SongDeleteViewModel.class);

        modelAndView.addObject(VIEW_MODEL_OBJECT_NAME, model);

        return view("song/delete-song", modelAndView);
    }

    @PostMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView deleteSongConfirm(@PathVariable String id) {
        this.songService.removeSongById(id);

        return redirect("/songs/all");
    }

    @GetMapping("/edit/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView editSong(@PathVariable String id, ModelAndView modelAndView) throws SongNotFoundException {
        SongEditViewModel song = this.modelMapper
                .map(this.songService.findById(id), SongEditViewModel.class);

        modelAndView.addObject(VIEW_MODEL_OBJECT_NAME, song);

        return view("song/edit-song", modelAndView);
    }

    @PostMapping("/edit/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView editSongConfirm(@PathVariable String id,
                                        @ModelAttribute(name = "model") SongEditBindingModel model) throws SongNotFoundException {

        SongServiceModel songServiceModel = this.modelMapper.map(model, SongServiceModel.class);

        this.songService.editSong(id, songServiceModel);

        return redirect("/songs/details/" + id);
    }
}
