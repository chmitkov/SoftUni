package funportal.web.controllers.RESTControllers;

import funportal.error.BoardGameNotFoundException;
import funportal.service.BoardGameService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/boardGames/")
public class BoardGameRestController {

    private final BoardGameService boardGameService;

    public BoardGameRestController(BoardGameService boardGameService) {
        this.boardGameService = boardGameService;
    }

    @GetMapping("/print/{id}")
    public String printBoard(@PathVariable String id) throws BoardGameNotFoundException {
        return this.boardGameService.findById(id)
                .getBoardImage();
    }
}
