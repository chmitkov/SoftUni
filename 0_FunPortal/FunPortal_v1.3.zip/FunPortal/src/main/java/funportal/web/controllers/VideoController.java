package funportal.web.controllers;

import funportal.domain.models.binding.VideoBindingModel;
import funportal.domain.models.service.VideoServiceModel;
import funportal.domain.models.view.video.VideoAllViewModel;
import funportal.domain.models.view.video.VideoDeleteViewModel;
import funportal.domain.models.view.video.VideoDetailsViewModel;
import funportal.domain.models.view.video.VideoEditViewModel;
import funportal.error.VideoNotFoundException;
import funportal.service.VideoService;
import funportal.validation.VideoValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/videos")
public class VideoController extends BaseController {

    private final VideoService videoService;
    private final ModelMapper modelMapper;
    private final VideoValidation videoValidation;

    @Autowired
    public VideoController(VideoService videoService, ModelMapper modelMapper, VideoValidation videoValidation) {
        this.videoService = videoService;
        this.modelMapper = modelMapper;
        this.videoValidation = videoValidation;
    }

    @GetMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addVideo() {
        return view("video/add-video");
    }

    @PostMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addVideoConfirm(@ModelAttribute(name = "model") VideoBindingModel model) {

        if (!this.videoValidation.isValid(model)) {
            return redirect("/videos/add");
        }

        VideoServiceModel serviceModel = this.modelMapper
                .map(model, VideoServiceModel.class);

        videoService.addVideo(serviceModel);

        return redirect("/videos/all");
    }

    @GetMapping("/all")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView allVideos(ModelAndView modelAndView) {
        List<VideoAllViewModel> videos = this.videoService
                .findAllVideosOrderByAddedOn()
                .stream()
                .map(v -> this.modelMapper.map(v, VideoAllViewModel.class))
                .collect(Collectors.toList());

        modelAndView.addObject("videos", videos);

        return view("video/all-videos", modelAndView);
    }

    @GetMapping("/details/{id}")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView details(@PathVariable String id, ModelAndView modelAndView) throws VideoNotFoundException {

        VideoDetailsViewModel video = this.modelMapper
                .map(this.videoService.findVideoById(id), VideoDetailsViewModel.class);

        modelAndView.addObject("model", video);
        return view("video/details-video", modelAndView);
    }


    @GetMapping("/like/{id}")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView likeVideo(@PathVariable String id, Principal principal) throws VideoNotFoundException {
        this.videoService.likeVideoById(id, principal.getName());

        return redirect("/videos/details/" + id);
    }

    @GetMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView deleteVideo(@PathVariable String id, ModelAndView modelAndView) throws VideoNotFoundException {
        VideoDeleteViewModel video = this.modelMapper
                .map(this.videoService.findVideoById(id), VideoDeleteViewModel.class);

        modelAndView.addObject("model", video);

        return view("video/delete-video", modelAndView);
    }

    @PostMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView deleteVideoConfirm(@PathVariable String id, Principal principal) throws VideoNotFoundException {
        this.videoService.removeVideoById(id, principal.getName());

        return redirect("/videos/all");
    }

    @GetMapping("/edit/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView editVideo(@PathVariable String id, ModelAndView modelAndView) throws VideoNotFoundException {
        VideoEditViewModel video = this.modelMapper
                .map(this.videoService.findVideoById(id), VideoEditViewModel.class);

        modelAndView.addObject("model", video);

        return view("video/edit-video", modelAndView);
    }

    @PostMapping("/edit/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView editVideoConfirm(@PathVariable String id,
                                         @ModelAttribute(name = "model") VideoEditViewModel model) throws VideoNotFoundException {

        VideoServiceModel videoServiceModel = this.modelMapper
                .map(model, VideoServiceModel.class);

        if (!this.videoValidation.isValid(videoServiceModel)) {
            return redirect("/videos/edit/" + id);
        }

        this.videoService.editVideo(id, videoServiceModel);

        return redirect("/videos/details/" + id);
    }

    @GetMapping("/favourites")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView favouriteVideos(Principal principal, ModelAndView modelAndView) {
        List<VideoAllViewModel> videos = this.videoService
                .findUserFavouriteVideos(principal.getName())
                .stream()
                .map(v -> this.modelMapper.map(v, VideoAllViewModel.class))
                .collect(Collectors.toList());

        modelAndView.addObject("videos", videos);

        return view("video/all-videos", modelAndView);
    }


    //Helper methods
    @InitBinder
    private void initBinder(WebDataBinder webDataBinder) {
        webDataBinder.registerCustomEditor(String.class,
                new StringTrimmerEditor(true));
    }
}
