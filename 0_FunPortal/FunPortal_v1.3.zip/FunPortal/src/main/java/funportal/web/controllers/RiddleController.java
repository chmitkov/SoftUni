package funportal.web.controllers;

import funportal.domain.models.binding.RiddleBindingModel;
import funportal.domain.models.binding.RiddleEditBindingModel;
import funportal.domain.models.service.RiddleServiceModel;
import funportal.domain.models.view.riddle.RiddleAllViewModel;
import funportal.domain.models.view.riddle.RiddleDeleteViewModel;
import funportal.domain.models.view.riddle.RiddleEditViewModel;
import funportal.error.RiddleNotFoundException;
import funportal.service.RiddleService;
import funportal.validation.RiddleValidation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.stream.Collectors;

import static funportal.web.GlobalConstants.VIEW_MODEL_OBJECT_NAME;

@Controller
@RequestMapping("/riddles")
public class RiddleController extends BaseController {


    private final RiddleService riddleService;
    private final RiddleValidation riddleValidation;
    private final ModelMapper modelMapper;

    @Autowired
    public RiddleController(RiddleService riddleService, RiddleValidation riddleValidation, ModelMapper modelMapper) {
        this.riddleService = riddleService;
        this.riddleValidation = riddleValidation;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addRiddle() {
        return view("riddle/add-riddle");
    }

    @PostMapping("/add")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView addRiddleConfirm(@ModelAttribute(name = "name") RiddleBindingModel model) {

        if (!this.riddleValidation.isValid(model)) {
            return view("riddle/add-riddle");
        }

        RiddleServiceModel riddleServiceModel = this.modelMapper
                .map(model, RiddleServiceModel.class);

        this.riddleService.addRiddle(riddleServiceModel);

        return redirect("/riddles/all");
    }

    @GetMapping("/all")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView allRiddles(ModelAndView modelAndView) {
        List<RiddleAllViewModel> riddles = this.riddleService
                .findAllOrderByAddedOn()
                .stream()
                .map(r -> this.modelMapper.map(r, RiddleAllViewModel.class))
                .collect(Collectors.toList());

        modelAndView.addObject("riddles", riddles);

        return view("riddle/all-riddles", modelAndView);
    }

    @GetMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView deleteRiddle(@PathVariable String id, ModelAndView modelAndView) throws RiddleNotFoundException {
        RiddleDeleteViewModel model = this.modelMapper
                .map(this.riddleService.findById(id), RiddleDeleteViewModel.class);

        modelAndView.addObject(VIEW_MODEL_OBJECT_NAME, model);

        return view("riddle/delete-riddle", modelAndView);
    }

    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView deleteRiddleConfirm(@PathVariable String id) {
        this.riddleService
                .removeById(id);

        return redirect("/riddles/all");
    }

    @GetMapping("/edit/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView editRiddle(@PathVariable String id, ModelAndView modelAndView) throws RiddleNotFoundException {
        RiddleEditViewModel riddleEditViewModel = this.modelMapper
                .map(this.riddleService.findById(id), RiddleEditViewModel.class);

        modelAndView.addObject(VIEW_MODEL_OBJECT_NAME, riddleEditViewModel);

        return view("riddle/edit-riddle", modelAndView);
    }

    @PatchMapping("/edit/{id}")
    @PreAuthorize("hasRole('ROLE_MODERATOR')")
    public ModelAndView editRiddleConfirm(@PathVariable String id,
                                          @ModelAttribute(name = "model") RiddleEditBindingModel model) throws RiddleNotFoundException {
        RiddleServiceModel riddleServiceModel = this.modelMapper
                .map(model, RiddleServiceModel.class);

        this.riddleService
                .editRiddle(id, riddleServiceModel);

        return redirect("/riddles/all");
    }
}
