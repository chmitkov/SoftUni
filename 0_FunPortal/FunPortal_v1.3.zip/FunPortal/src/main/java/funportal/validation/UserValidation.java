package funportal.validation;

import funportal.domain.entities.User;
import funportal.domain.models.binding.UserRegisterBindingModel;

public interface UserValidation {

    boolean isValid(UserRegisterBindingModel userRegisterBindingModel);

    boolean isValid(User user);
}
