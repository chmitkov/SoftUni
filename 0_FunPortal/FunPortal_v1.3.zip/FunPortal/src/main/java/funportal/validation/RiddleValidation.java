package funportal.validation;

import funportal.domain.models.binding.RiddleBindingModel;
import funportal.domain.models.service.RiddleServiceModel;

public interface RiddleValidation {

    boolean isValid(RiddleBindingModel riddleBindingModel);

    boolean isValid(RiddleServiceModel riddleServiceModel);
}
