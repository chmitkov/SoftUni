package funportal.validation.implementation;

import funportal.domain.models.binding.RiddleBindingModel;
import funportal.domain.models.service.RiddleServiceModel;
import funportal.validation.RiddleValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Validator;

@Component
public class RiddleImpl implements RiddleValidation {

    private final Validator validator;

    @Autowired
    public RiddleImpl(Validator validator) {
        this.validator = validator;
    }

    @Override
    public boolean isValid(RiddleBindingModel riddleBindingModel) {
        return this.validator.validate(riddleBindingModel).isEmpty();
    }

    @Override
    public boolean isValid(RiddleServiceModel riddleServiceModel) {
        return this.validator.validate(riddleServiceModel).isEmpty();
    }
}
