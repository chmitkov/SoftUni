package funportal.validation;

import funportal.domain.models.binding.TaleBindingModel;
import funportal.domain.models.service.TaleServiceModel;

public interface TaleValidation {

    boolean isValid(TaleServiceModel taleServiceModel);

    boolean isValid(TaleBindingModel taleBindingModel);
}
