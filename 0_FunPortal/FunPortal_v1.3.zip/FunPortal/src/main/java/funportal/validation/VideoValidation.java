package funportal.validation;

import funportal.domain.models.binding.VideoBindingModel;
import funportal.domain.models.service.VideoServiceModel;

public interface VideoValidation {

    boolean isValid(VideoBindingModel videoBindingModel);

    boolean isValid(VideoServiceModel videoServiceModel);
}
