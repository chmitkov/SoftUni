package funportal.domain.entities;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "origami")
public class Origami extends BaseEntity {

    private String name;
    private String titleImage;
    private String description;
    private String videoUrl;
    private List<OrigamiStep> steps;
    private LocalDateTime addedOn;

    public Origami() {
        this.steps = new ArrayList<>();
    }

    @Column(name = "name", nullable = false, unique = true)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "title_image")
    public String getTitleImage() {
        return titleImage;
    }

    public void setTitleImage(String titleImage) {
        this.titleImage = titleImage;
    }

    @Column(name = "description", nullable = false, columnDefinition = "TEXT")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "video_url")
    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    @ManyToMany(targetEntity = OrigamiStep.class, fetch = FetchType.EAGER)
    @JoinTable(
            name = "origami_origami_steps",
            joinColumns = @JoinColumn(name = "origami_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "origami_step_id", referencedColumnName = "id")
    )
    public List<OrigamiStep> getSteps() {
        return steps;
    }

    public void setSteps(List<OrigamiStep> steps) {
        this.steps = steps;
    }

    @Column(name = "added_on")
    public LocalDateTime getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(LocalDateTime addedOn) {
        this.addedOn = addedOn;
    }
}
