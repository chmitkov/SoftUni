package funportal.domain.models.service;

public class OrigamiStepServiceModel extends BaseServiceModel {

    private String imageUrl;
    private String description;

    public OrigamiStepServiceModel() {
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
