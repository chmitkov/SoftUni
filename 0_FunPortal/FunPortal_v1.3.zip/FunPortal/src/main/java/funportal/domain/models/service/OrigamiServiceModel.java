package funportal.domain.models.service;

import org.springframework.lang.NonNull;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class OrigamiServiceModel extends BaseServiceModel {

    private String name;
    private String titleImage;
    private String description;
    private String videoUrl;
    private List<OrigamiStepServiceModel> steps;
    private LocalDateTime addedOn;

    public OrigamiServiceModel() {
        this.steps = new ArrayList<>();
    }

    @NotEmpty
    @NonNull
    @Size(min = 2)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitleImage() {
        return titleImage;
    }

    public void setTitleImage(String titleImage) {
        this.titleImage = titleImage;
    }

    @NotEmpty
    @NonNull
    @Size(min = 2)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public List<OrigamiStepServiceModel> getSteps() {
        return steps;
    }

    public void setSteps(List<OrigamiStepServiceModel> steps) {
        this.steps = steps;
    }

    public LocalDateTime getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(LocalDateTime addedOn) {
        this.addedOn = addedOn;
    }
}
