package funportal.domain.models.view.origami;

import funportal.domain.entities.OrigamiStep;

import java.util.List;

public class OrigamiDetailsViewModel {

    private String id;
    private String name;
    private String titleImage;
    private String description;
    private String videoUrl;
    private List<OrigamiStep> steps;

    public OrigamiDetailsViewModel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitleImage() {
        return titleImage;
    }

    public void setTitleImage(String titleImage) {
        this.titleImage = titleImage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public List<OrigamiStep> getSteps() {
        return steps;
    }

    public void setSteps(List<OrigamiStep> steps) {
        this.steps = steps;
    }
}
