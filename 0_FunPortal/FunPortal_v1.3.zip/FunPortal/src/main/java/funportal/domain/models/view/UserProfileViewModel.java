package funportal.domain.models.view;

import funportal.domain.entities.Video;
import funportal.domain.models.service.ArticleServiceModel;
import funportal.domain.models.service.CommentServiceModel;

import java.time.LocalDateTime;
import java.util.Set;

public class UserProfileViewModel {

    private String id;
    private String username;
    private String email;
    private String imageUrl;
    private Set<Video> favouriteVideos;
    private Set<ArticleServiceModel> favouriteArticles;
    private Set<ArticleServiceModel> myArticles;
    private Set<CommentServiceModel> myComments;
    private LocalDateTime registeredOn;

    public UserProfileViewModel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Set<Video> getFavouriteVideos() {
        return favouriteVideos;
    }

    public void setFavouriteVideos(Set<Video> favouriteVideos) {
        this.favouriteVideos = favouriteVideos;
    }

    public Set<ArticleServiceModel> getFavouriteArticles() {
        return favouriteArticles;
    }

    public void setFavouriteArticles(Set<ArticleServiceModel> favouriteArticles) {
        this.favouriteArticles = favouriteArticles;
    }

    public Set<ArticleServiceModel> getMyArticles() {
        return myArticles;
    }

    public void setMyArticles(Set<ArticleServiceModel> myArticles) {
        this.myArticles = myArticles;
    }

    public LocalDateTime getRegisteredOn() {
        return registeredOn;
    }

    public void setRegisteredOn(LocalDateTime registeredOn) {
        this.registeredOn = registeredOn;
    }

    public Set<CommentServiceModel> getMyComments() {
        return myComments;
    }

    public void setMyComments(Set<CommentServiceModel> myComments) {
        this.myComments = myComments;
    }
}
