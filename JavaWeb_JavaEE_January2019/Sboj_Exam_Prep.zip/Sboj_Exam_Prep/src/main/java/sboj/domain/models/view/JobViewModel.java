package sboj.domain.models.view;

public class JobViewModel extends BaseViewModel {

    private String sector;
    private String profession;

    public JobViewModel() {
    }

    public String getSector() {
        return sector;
    }

    public void setSector(String sector) {
        this.sector = sector;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }
}
