package sboj.domain.models.view;

public class JobDeleteViewModel extends BaseViewModel {

}
