package sboj.domain.entities;

public enum Sector {
    Medicine, Car, Food, Domestic, Security;
}
