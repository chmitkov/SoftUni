package sboj.repository;

import sboj.domain.entities.JobApplication;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;

public class JobRepositoryImpl implements JobRepository {

    private final EntityManager entityManager;

    @Inject
    public JobRepositoryImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public JobApplication save(JobApplication entity) {
        this.entityManager.getTransaction().begin();
        try {
            this.entityManager.persist(entity);
            this.entityManager.getTransaction().commit();

            return entity;
        } catch (Exception e) {
            this.entityManager.getTransaction().rollback();

            return null;
        }
    }

    @Override
    public JobApplication update(JobApplication entity) {
        this.entityManager.getTransaction().begin();
        try {
            JobApplication updatedUser = this.entityManager.merge(entity);
            this.entityManager.getTransaction().commit();

            return updatedUser;
        } catch (Exception e) {
            this.entityManager.getTransaction().rollback();

            return null;
        }
    }

    @Override
    public List<JobApplication> findAll() {
        this.entityManager.getTransaction().begin();
        List<JobApplication> jobs = this.entityManager
                .createQuery("SELECT j FROM JobApplication j ", JobApplication.class)
                .getResultList();
        this.entityManager.getTransaction().commit();

        return jobs;
    }

    @Override
    public JobApplication findById(String s) {
        this.entityManager.getTransaction().begin();
        try {
            JobApplication jobApplication = this.entityManager
                    .createQuery("SELECT u FROM JobApplication u WHERE u.id = :id", JobApplication.class)
                    .setParameter("id", s)
                    .getSingleResult();

            this.entityManager.getTransaction().commit();
            return jobApplication;
        } catch (Exception e) {
            this.entityManager.getTransaction().rollback();
            return null;
        }
    }

    @Override
    public void removeById(String id) {
        this.entityManager.getTransaction().begin();
        try {

            this.entityManager
                    .createQuery("DELETE FROM JobApplication j WHERE j.id = :id")
                    .setParameter("id", id)
                    .executeUpdate();

            this.entityManager.getTransaction().commit();

        } catch (Exception e) {
            this.entityManager.getTransaction().rollback();

        }
    }
}
