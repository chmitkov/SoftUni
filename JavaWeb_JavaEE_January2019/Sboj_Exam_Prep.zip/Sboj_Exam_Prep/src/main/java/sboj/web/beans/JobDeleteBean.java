package sboj.web.beans;


import org.modelmapper.ModelMapper;
import sboj.domain.models.service.JobServiceModel;
import sboj.domain.models.view.JobDetailsViewModel;
import sboj.service.JobService;

import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;

@Named
@RequestScoped
public class JobDeleteBean {

    private JobDetailsViewModel jobDetailsViewModel;

    private JobService jobService;
    private ModelMapper modelMapper;

    public JobDeleteBean() {
    }

    @Inject
    public JobDeleteBean(JobService jobService, ModelMapper modelMapper) {
        this.jobService = jobService;
        this.modelMapper = modelMapper;
        this.initModel();
    }

    private void initModel() {
        String id = (String) FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .get("currentId");

        JobServiceModel serviceModel = this.jobService.findById(id);

        this.jobDetailsViewModel = this.modelMapper
                .map(serviceModel, JobDetailsViewModel.class);
    }

    public JobDetailsViewModel getJobDetailsViewModel() {
        return jobDetailsViewModel;
    }

    public void setJobDetailsViewModel(JobDetailsViewModel jobDetailsViewModel) {
        this.jobDetailsViewModel = jobDetailsViewModel;
    }

    public void deleteJob() throws IOException {
        this.jobService
                .deleteJob(this.jobDetailsViewModel.getId());

        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .redirect("/home");
    }
}
