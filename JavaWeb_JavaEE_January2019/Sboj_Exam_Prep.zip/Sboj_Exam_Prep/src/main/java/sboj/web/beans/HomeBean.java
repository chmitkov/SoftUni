package sboj.web.beans;

import org.modelmapper.ModelMapper;
import sboj.domain.models.view.JobViewModel;
import sboj.service.JobService;

import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Named
@RequestScoped
public class HomeBean {

    private List<JobViewModel> jobs;

    private JobService jobService;
    private ModelMapper modelMapper;

    public HomeBean() {
    }

    @Inject
    public HomeBean(JobService jobService, ModelMapper modelMapper) {
        this.jobService = jobService;
        this.modelMapper = modelMapper;
        this.initModel();
    }

    private void initModel() {
        this.jobs = this.jobService
                .findAllJobs()
                .stream()
                .map(j -> this.modelMapper.map(j, JobViewModel.class))
                .collect(Collectors.toList());
    }

    public List<JobViewModel> getJobs() {
        return this.jobs;
    }

    public void setJobs(List<JobViewModel> jobs) {
        this.jobs = jobs;
    }

    public void jobDetails(String id) throws IOException {
        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .put("currentId", id);

        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .redirect("/details");
    }

    public void deleteJob(String id) throws IOException {
        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .put("currentId", id);

        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .redirect("/delete");
    }
}
