package sboj.web.beans;

import org.modelmapper.ModelMapper;
import sboj.domain.models.binding.JobBindingModel;
import sboj.domain.models.service.JobServiceModel;
import sboj.service.JobService;

import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;

@Named
@RequestScoped
public class AddJobBean {

    private JobBindingModel jobBindingModel;

    private JobService jobService;
    private ModelMapper modelMapper;

    public AddJobBean() {
    }

    @Inject
    public AddJobBean(JobService jobService, ModelMapper modelMapper) {
        this.jobService = jobService;
        this.modelMapper = modelMapper;
        this.initModel();
    }

    private void initModel() {
        this.jobBindingModel = new JobBindingModel();
    }

    public JobBindingModel getJobBindingModel() {
        return jobBindingModel;
    }

    public void setJobBindingModel(JobBindingModel jobBindingModel) {
        this.jobBindingModel = jobBindingModel;
    }

    public void addJob() throws IOException {
        JobServiceModel jobServiceModel = this.modelMapper
                .map(this.jobBindingModel, JobServiceModel.class);

        this.jobService.addJob(jobServiceModel);

        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .redirect("/home");
    }
}

