package sboj.service;

import sboj.domain.models.service.JobServiceModel;

import java.util.List;

public interface JobService {

    void addJob(JobServiceModel jobServiceModel);

    List<JobServiceModel> findAllJobs();

    JobServiceModel findById(String id);

    void deleteJob(String id);
}
