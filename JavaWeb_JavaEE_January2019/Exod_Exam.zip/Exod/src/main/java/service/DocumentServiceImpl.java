package service;

import domain.entities.Document;
import domain.models.service.DocumentServiceModel;
import org.modelmapper.ModelMapper;
import repository.DocumentRepository;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;

public class DocumentServiceImpl implements DocumentService {

    private final DocumentRepository documentRepository;
    private final ModelMapper modelMapper;

    @Inject
    public DocumentServiceImpl(DocumentRepository documentRepository, ModelMapper modelMapper) {
        this.documentRepository = documentRepository;
        this.modelMapper = modelMapper;
    }


    @Override
    public boolean saveDocument(DocumentServiceModel documentServiceModel) {
        Document document = this.modelMapper
                .map(documentServiceModel, Document.class);

        return this.documentRepository
                .save(document) != null;
    }

    @Override
    public List<DocumentServiceModel> findAllDocuments() {
        return this.documentRepository
                .findAll()
                .stream()
                .map(d -> this.modelMapper.map(d, DocumentServiceModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public DocumentServiceModel findById(String id) {
        return this.modelMapper
                .map(this.documentRepository
                        .findById(id), DocumentServiceModel.class);
    }

    @Override
    public void deleteDocumentById(String id) {
        this.documentRepository
                .removeById(id);
    }
}
