package service;


import domain.models.service.UserServiceModel;

public interface UserService {

    boolean registerUser(UserServiceModel userServiceModel);

    UserServiceModel loginUser(UserServiceModel userServiceModel);

//    UserServiceModel findUserById(String id);
//
//    List<UserServiceModel> findAll();
//
//    boolean addFriend(UserServiceModel userServiceModel);
//
//    boolean removeFriend(UserServiceModel userServiceModel);
//
//    void removeFriendsConnection(String firstId, String secondId);
}
