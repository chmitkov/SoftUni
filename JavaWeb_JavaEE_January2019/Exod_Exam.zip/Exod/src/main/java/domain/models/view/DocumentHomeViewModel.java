package domain.models.view;

public class DocumentHomeViewModel extends BaseViewModel {

    private String title;

    public DocumentHomeViewModel() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
