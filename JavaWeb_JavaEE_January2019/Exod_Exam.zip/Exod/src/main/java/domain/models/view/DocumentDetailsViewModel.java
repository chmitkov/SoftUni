package domain.models.view;

public class DocumentDetailsViewModel extends BaseViewModel {

    private String title;
    private String content;

    public DocumentDetailsViewModel() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
