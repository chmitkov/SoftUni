package web.beans;

import domain.models.view.DocumentDeleteViewModel;
import org.modelmapper.ModelMapper;
import service.DocumentService;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;

@Named
@RequestScoped
public class DocumentDeleteBean {

    private DocumentDeleteViewModel documentDeleteViewModel;

    private DocumentService documentService;
    private ModelMapper modelMapper;

    public DocumentDeleteBean() {
    }

    @Inject
    public DocumentDeleteBean(DocumentService documentService, ModelMapper modelMapper) {
        this.documentService = documentService;
        this.modelMapper = modelMapper;
    }

    @PostConstruct
    public void initModel() {
        String currentId = (String) FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .get("currentId");

        this.documentDeleteViewModel = this.modelMapper
                .map(this.documentService.findById(currentId), DocumentDeleteViewModel.class);
    }

    public DocumentDeleteViewModel getDocumentDeleteViewModel() {
        return documentDeleteViewModel;
    }

    public void setDocumentDeleteViewModel(DocumentDeleteViewModel documentDeleteViewModel) {
        this.documentDeleteViewModel = documentDeleteViewModel;
    }

    public void delete() throws IOException {
        this.documentService
                .deleteDocumentById(this.documentDeleteViewModel.getId());

        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .redirect("/home");
    }
}
