package web.beans;

import domain.models.view.DocumentDetailsViewModel;
import org.modelmapper.ModelMapper;
import service.DocumentService;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

@Named
@RequestScoped
public class DocumentDetailsBean {

    private DocumentDetailsViewModel documentDetailsViewModel;

    private DocumentService documentService;
    private ModelMapper modelMapper;

    public DocumentDetailsBean() {
    }

    @Inject
    public DocumentDetailsBean(DocumentService documentService, ModelMapper modelMapper) {
        this.documentService = documentService;
        this.modelMapper = modelMapper;
    }

    @PostConstruct
    public void initModel() {
        String currentId = (String) FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .get("currentId");

        this.documentDetailsViewModel = this.modelMapper
                .map(this.documentService
                        .findById(currentId), DocumentDetailsViewModel.class);
    }

    public DocumentDetailsViewModel getDocumentDetailsViewModel() {
        return documentDetailsViewModel;
    }

    public void setDocumentDetailsViewModel(DocumentDetailsViewModel documentDetailsViewModel) {
        this.documentDetailsViewModel = documentDetailsViewModel;
    }
}
