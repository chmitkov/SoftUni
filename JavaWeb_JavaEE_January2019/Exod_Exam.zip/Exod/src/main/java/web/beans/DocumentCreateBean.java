package web.beans;

import domain.models.binding.DocumentBindingModel;
import domain.models.service.DocumentServiceModel;
import org.modelmapper.ModelMapper;
import service.DocumentService;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;

@Named
@RequestScoped
public class DocumentCreateBean {

    private DocumentBindingModel documentBindingModel;

    private DocumentService documentService;
    private ModelMapper modelMapper;

    public DocumentCreateBean() {
    }

    @Inject
    public DocumentCreateBean(DocumentService documentService, ModelMapper modelMapper) {
        this.documentService = documentService;
        this.modelMapper = modelMapper;
    }

    @PostConstruct
    public void initModel() {
        this.documentBindingModel = new DocumentBindingModel();
    }

    public DocumentBindingModel getDocumentBindingModel() {
        return documentBindingModel;
    }

    public void setDocumentBindingModel(DocumentBindingModel documentBindingModel) {
        this.documentBindingModel = documentBindingModel;
    }

    public void create() throws IOException {
        DocumentServiceModel documentServiceModel = this.modelMapper
                .map(this.documentBindingModel, DocumentServiceModel.class);

        if (!this.documentService.saveDocument(documentServiceModel)) {
            throw new IllegalArgumentException("Cannot add document!");
        }

        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .redirect("/home");
    }
}
