package web.beans;

import domain.entities.Document;
import domain.models.view.DocumentHomeViewModel;
import org.modelmapper.ModelMapper;
import service.DocumentService;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Named
@RequestScoped
public class HomeBean {

    private List<DocumentHomeViewModel> documents;

    private DocumentService documentService;
    private ModelMapper modelMapper;

    public HomeBean() {
    }

    @Inject
    public HomeBean(DocumentService documentService, ModelMapper modelMapper) {
        this.documentService = documentService;
        this.modelMapper = modelMapper;
    }

    @PostConstruct
    public void initModel() {
        this.documents = this.documentService
                .findAllDocuments()
                .stream()
                .map(d -> this.modelMapper.map(d, DocumentHomeViewModel.class))
                .peek(d -> {
                    if (d.getTitle().length() > 12) {
                        d.setTitle(d.getTitle().substring(0, 11) + "...");
                    }
                })
                .collect(Collectors.toList());
    }

    public List<DocumentHomeViewModel> getDocuments() {
        return documents;
    }

    public void setDocuments(List<DocumentHomeViewModel> documents) {
        this.documents = documents;
    }

    public void print(String id) throws IOException {
        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .put("currentId", id);

        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .redirect("/delete");
    }

    public void details(String id) throws IOException {
        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .put("currentId", id);

        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .redirect("/details");
    }
}
