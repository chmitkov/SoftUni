package app.web.mbeans;

import app.domain.entities.JobApplication;
import app.domain.models.binding.JobApplicationCreateBindingModel;
import app.domain.models.service.JobApplicationServiceModel;
import app.service.JobApplicationService;
import org.modelmapper.ModelMapper;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.math.BigDecimal;

@Named("jobApplicationCreateBean")
@RequestScoped
public class JobApplicationCreateBean extends BaseBean {

    private JobApplicationCreateBindingModel jobApplicationCreateBindingModel;

    private JobApplicationService jobApplicationService;
    private ModelMapper modelMapper;

    public JobApplicationCreateBean() {
    }

    @Inject
    public JobApplicationCreateBean(JobApplicationService jobApplicationService, ModelMapper modelMapper) {
        this.jobApplicationService = jobApplicationService;
        this.modelMapper = modelMapper;
    }

    @PostConstruct
    public void init() {
        this.jobApplicationCreateBindingModel = new JobApplicationCreateBindingModel();
    }

    public JobApplicationCreateBindingModel getJobApplicationCreateBindingModel() {
        return jobApplicationCreateBindingModel;
    }

    public void setJobApplicationCreateBindingModel(JobApplicationCreateBindingModel jobApplicationCreateBindingModel) {
        this.jobApplicationCreateBindingModel = jobApplicationCreateBindingModel;
    }

    public void createJobApplication() {

        this.jobApplicationService
                .createJobApplication(this.modelMapper
                        .map(this.jobApplicationCreateBindingModel, JobApplicationServiceModel.class));

        this.redirect("home");
    }
}
