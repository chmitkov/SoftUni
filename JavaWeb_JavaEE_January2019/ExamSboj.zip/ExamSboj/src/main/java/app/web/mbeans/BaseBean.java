package app.web.mbeans;

import javax.faces.context.FacesContext;

public abstract class BaseBean {
    protected void redirect(String url) {
        try {
            FacesContext
                    .getCurrentInstance()
                    .getExternalContext()
                    .redirect("/ExamSboj_war_exploded/views/" + url + ".xhtml");
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
