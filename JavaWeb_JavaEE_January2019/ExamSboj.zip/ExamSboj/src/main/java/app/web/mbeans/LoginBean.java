package app.web.mbeans;

import app.domain.models.binding.UserLoginBindingModel;
import app.domain.models.service.UserServiceModel;
import app.repository.UserRepository;
import org.apache.commons.codec.digest.DigestUtils;
import org.modelmapper.ModelMapper;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.util.Map;

@Named("loginBean")
@RequestScoped
public class LoginBean extends BaseBean {

    private UserLoginBindingModel userLoginBindingModel;

    private UserRepository userRepository;
    private ModelMapper modelMapper;

    public LoginBean() {
    }

    @Inject
    public LoginBean(UserRepository userRepository, ModelMapper modelMapper) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
    }

    @PostConstruct
    public void init() {
        this.userLoginBindingModel = new UserLoginBindingModel();
    }

    public UserLoginBindingModel getUserLoginBindingModel() {
        return userLoginBindingModel;
    }

    public void setUserLoginBindingModel(UserLoginBindingModel userLoginBindingModel) {
        this.userLoginBindingModel = userLoginBindingModel;
    }

    public void login() throws IOException {
//        List<User> users = this.userRepository.findAll();
//
//        System.out.println();

        UserServiceModel userServiceModel = this.modelMapper
                .map(this.userRepository
                                .findByUsername(this.userLoginBindingModel.getUsername()),
                        UserServiceModel.class);


        if (userServiceModel == null ||
                !DigestUtils.sha256Hex(this.userLoginBindingModel.getPassword()).equals(
                        userServiceModel.getPassword())) {
            return;
        }

        saveIdAndUsernameToSessionMap(
                userServiceModel.getId(), userServiceModel.getUsername());

        this.redirect("home");
    }

    private void saveIdAndUsernameToSessionMap(String id, String username) {
        Map<String, Object> sessionMap = FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap();

        sessionMap.put("user-id", id);
        sessionMap.put("username", username);

    }
}
