package app.web.mbeans;

import app.domain.entities.User;
import app.domain.models.binding.UserRegisterBindingModel;
import app.domain.models.service.UserServiceModel;
import app.repository.UserRepository;
import app.service.UserService;
import org.apache.commons.codec.digest.DigestUtils;
import org.modelmapper.ModelMapper;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named("registerBean")
@RequestScoped
public class RegisterBean extends BaseBean {

    private UserRegisterBindingModel userRegisterBindingModel;


    private ModelMapper modelMapper;
    private UserRepository userRepository;
    //This is wrong to be here


    public RegisterBean() {
    }

    @Inject
    public RegisterBean(UserRepository userRepository, ModelMapper modelMapper) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
    }

    @PostConstruct
    public void init() {
        this.userRegisterBindingModel = new UserRegisterBindingModel();
    }

    public UserRegisterBindingModel getUserRegisterBindingModel() {
        return userRegisterBindingModel;
    }

    public void setUserRegisterBindingModel(UserRegisterBindingModel userRegisterBindingModel) {
        this.userRegisterBindingModel = userRegisterBindingModel;
    }

    public void register() {
        if (!this.userRegisterBindingModel.getPassword()
                .equals(this.userRegisterBindingModel.getConfirmPassword())) {
            return;
        }

        this.userRegisterBindingModel.setPassword(
                DigestUtils.sha256Hex(this.userRegisterBindingModel.getPassword())
        );

        this.userRepository.save(
                this.modelMapper.map(this.userRegisterBindingModel, User.class));
        this.redirect("login");
    }
}
