package app.web.mbeans;

import app.domain.models.service.JobApplicationServiceModel;
import app.service.JobApplicationService;
import org.modelmapper.ModelMapper;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

@Named("jobApplicationListBean")
@RequestScoped
public class JobApplicationListBean {

    private JobApplicationService jobApplicationService;

    private List<JobApplicationServiceModel> jobApplications;

    public JobApplicationListBean() {
    }

    @Inject
    public JobApplicationListBean(JobApplicationService jobApplicationService, ModelMapper modelMapper) {
        this.jobApplicationService = jobApplicationService;
    }

    @PostConstruct
    public void init(){
        this.setJobApplications(this.jobApplicationService.findAllJobApplications());
        this.getJobApplications()
                .forEach(x->x.setSector(x.getSector().toLowerCase()));
        System.out.println();
    }

    public List<JobApplicationServiceModel> getJobApplications() {
        return jobApplications;
    }

    public void setJobApplications(List<JobApplicationServiceModel> jobApplications) {
        this.jobApplications = jobApplications;
    }

}
