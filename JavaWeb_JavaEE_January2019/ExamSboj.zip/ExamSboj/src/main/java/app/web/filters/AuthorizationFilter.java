package app.web.filters;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter({"/views/home.xhtml", "/views/add-job.xhtml",
        "/views/delete-job.xhtml", "/views/details-job.xhtml"})
public class AuthorizationFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        String userId = (String) ((HttpServletRequest) request)
                .getSession()
                .getAttribute("user-id");

        if (userId == null) {
            ((HttpServletResponse) response)
                    .sendRedirect("/ExamSboj_war_exploded/views/login.xhtml");
            return;
        }

        chain.doFilter(request, response);
    }
}
