package app.repository;

import app.domain.entities.User;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;

public class UserRepositoryIml extends BaseRepository implements UserRepository {

    @Inject
    protected UserRepositoryIml(EntityManager entityManager) {
        super(entityManager);
    }

    @Override
    public User findByUsername(String username) {
        return this.getEntityManager()
                .createQuery("SELECT u FROM app.domain.entities.User u WHERE u.username = :username", User.class)
                .setParameter("username", username)
                .getSingleResult();
    }

    @Override
    public User save(User entity) {
        return this.executeTransaction((em) -> {
            em.persist(entity);
            return entity;
        });
    }

    @Override
    public List<User> findAll() {
        return this.getEntityManager()
                .createNativeQuery("SELECT * FROM users", User.class)
                .getResultList();
    }

    @Override
    public User findById(String id) {
        return this.getEntityManager()
                .createQuery("SELECT u FROM Users u WHERE u.id = :id", User.class)
                .setParameter("id", id)
                .getSingleResult();
    }
}
