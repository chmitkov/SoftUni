package app.service;

import app.domain.models.service.JobApplicationServiceModel;

import java.util.List;

public interface JobApplicationService {

    JobApplicationServiceModel createJobApplication(JobApplicationServiceModel jobApplicationServiceModel);

    List<JobApplicationServiceModel> findAllJobApplications();

    JobApplicationServiceModel findById(String id);

    void delete(String id);
}
