package app.web.mbeans;

import app.service.EmployeeService;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.stream.Collectors;

@Named
@RequestScoped
public class EmployeesMoneyFuncBean {


    private EmployeeService employeeService;

    public EmployeesMoneyFuncBean() {
    }

    @Inject
    public EmployeesMoneyFuncBean(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    public double getAllNeededMoney() {
        return this.employeeService
                .findAllEmployees()
                .stream()
                .map(e -> String.valueOf(e.getSalary()))
                .mapToDouble(Double::parseDouble)
                .reduce(Double::sum)
                .getAsDouble();
    }

    public double averageSalary() {
        int employeesCount = this.employeeService
                .findAllEmployees()
                .size();

        double allMoney =  this.employeeService
                .findAllEmployees()
                .stream()
                .map(e -> String.valueOf(e.getSalary()))
                .mapToDouble(Double::parseDouble)
                .reduce(Double::sum)
                .getAsDouble();

        return allMoney/employeesCount;
    }
}
