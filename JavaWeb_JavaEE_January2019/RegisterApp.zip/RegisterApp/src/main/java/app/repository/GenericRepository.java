package app.repository;

import java.util.List;

public interface GenericRepository<Entity, ID> {
    Entity saveEntity(Entity entity);

    List<Entity> findAll();

    Entity findById(ID id);

    void remove(ID id);
}
