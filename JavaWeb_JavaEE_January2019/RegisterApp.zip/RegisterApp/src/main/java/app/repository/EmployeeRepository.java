package app.repository;

import app.domain.entities.Employee;

public interface EmployeeRepository extends GenericRepository<Employee, String> {
}
