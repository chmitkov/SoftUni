package app.service;

import app.domain.models.CatServiceModel;

public interface CatService {
    boolean saveCat(CatServiceModel catServiceModel);
}
