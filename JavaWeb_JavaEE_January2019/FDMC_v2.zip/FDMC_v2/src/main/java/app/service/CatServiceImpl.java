package app.service;

import app.domain.entities.Cat;
import app.domain.models.CatServiceModel;
import app.repository.CatRepository;
import org.modelmapper.ModelMapper;

import javax.inject.Inject;

public class CatServiceImpl implements CatService {

    private final CatRepository catRepository;
    private final ModelMapper modelMapper;

    @Inject
    public CatServiceImpl(CatRepository catRepository, ModelMapper modelMapper) {
        this.catRepository = catRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public boolean saveCat(CatServiceModel catServiceModel) {
        try {
            this.catRepository
                    .save(this.modelMapper.map(catServiceModel, Cat.class));
        } catch (Exception e) {
            return false;
        }

        return true;
    }
}
