package casebook.service;

import casebook.domain.models.service.UserServiceModel;

import java.util.List;

public interface UserService {

    boolean registerUser(UserServiceModel userServiceModel);

    UserServiceModel loginUser(UserServiceModel userServiceModel);

    UserServiceModel findUserById(String id);

    List<UserServiceModel> findAll();

    boolean addFriend(UserServiceModel userServiceModel);

    boolean removeFriend(UserServiceModel userServiceModel);

    void removeFriendsConnection(String firstId, String secondId);
}
