package casebook.web.beans;

import casebook.domain.models.service.UserServiceModel;
import casebook.domain.models.view.UserFriendsViewModel;
import casebook.service.UserService;
import org.modelmapper.ModelMapper;

import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Named
@RequestScoped
public class UserFriendsBean {

    private List<UserFriendsViewModel> userFriendsViewModels;

    private UserService userService;
    private ModelMapper modelMapper;

    public UserFriendsBean() {
    }

    @Inject
    public UserFriendsBean(UserService userService, ModelMapper modelMapper) {
        this.userService = userService;
        this.modelMapper = modelMapper;
        this.initModel();
    }

    private void initModel() {
        String id = (String) FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .get("id");

        this.userFriendsViewModels = this.userService
                .findUserById(id)
                .getFriend()
                .stream()
                .map(f -> this.modelMapper.map(f, UserFriendsViewModel.class))
                .collect(Collectors.toList());
    }

    public List<UserFriendsViewModel> getUserFriendsViewModels() {
        return userFriendsViewModels;
    }

    public void setUserFriendsViewModels(List<UserFriendsViewModel> userFriendsViewModels) {
        this.userFriendsViewModels = userFriendsViewModels;
    }

    public void removeFriend(String id) throws IOException {
        String loggedInId = (String) FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .getSessionMap()
                .get("id");

        UserServiceModel loggedInServiceModel = this.userService
                .findUserById(loggedInId);

        UserServiceModel friendServiceModel = this.userService
                .findUserById(id);

        this.userService.removeFriendsConnection(loggedInId, id);
//        loggedInServiceModel.getFriend().remove(friendServiceModel);
//        friendServiceModel.getFriend().remove(loggedInServiceModel);
//
//        if(!this.userService.removeFriend(loggedInServiceModel)){
//            throw new IllegalArgumentException("Can't remove friend");
//        }
//
//        if(!this.userService.removeFriend(friendServiceModel)){
//            throw new IllegalArgumentException("Can't remove friend");
//        }

        FacesContext
                .getCurrentInstance()
                .getExternalContext()
                .redirect("/friends");
    }
}
