package casebook.domain.entities;

public enum Gender {

    MALE, FEMALE;
}
