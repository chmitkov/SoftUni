﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObjectsAndClasses_Lab_04.DistanceBetweenPoints
{
    class Point
    {
        public int x { get; set; }
        public int y { get; set; }
    }
}
