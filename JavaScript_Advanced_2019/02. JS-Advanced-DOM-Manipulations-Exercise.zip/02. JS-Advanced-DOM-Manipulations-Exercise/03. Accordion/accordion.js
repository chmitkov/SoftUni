function toggle(ev) {
    const spanButton = document.querySelector('.button');
    const divToShowElement = document.getElementById('extra');
    let spanText = spanButton.innerHTML;

    if (spanText === 'More') {
        divToShowElement.style.display = 'block';
        spanButton.innerHTML = 'Less';
    } else {
        divToShowElement.style.display = 'none';
        spanButton.innerHTML = 'More';
    }
}