function notify(message) {
    const divElement = document.getElementById('notification');
    divElement.style.display = 'block';
    divElement.textContent = message;
    setTimeout(function () {
        //divElement.innerText = '';
        divElement.style.display = 'none';
    }, 2000);
}