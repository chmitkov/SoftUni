function attachEventsListeners() {

    const inputDaysElement = document.getElementById('days');
    const inputHoursElement = document.getElementById('hours');
    const inputMinutesElement = document.getElementById('minutes');
    const inputSecondsElement = document.getElementById('seconds');

    const convertDays = document.getElementById('daysBtn');
    convertDays.addEventListener('click', action);

    const convertHours = document.getElementById('hoursBtn');
    convertHours.addEventListener('click', action);

    const convertMinutes = document.getElementById('minutesBtn');
    convertMinutes.addEventListener('click', action);

    const convertSeconds = document.getElementById('secondsBtn');
    convertSeconds.addEventListener('click', action);

    function clearAllFields() {
        inputDaysElement.value = '';
        inputHoursElement.value = '';
        inputMinutesElement.value = '';
        inputSecondsElement.value = '';
    }
    function getTimeFromAllInputAndReturnInSeconds() {
        return +inputSecondsElement.value
            + +inputMinutesElement.value * 60
            + +inputHoursElement.value * 3600
            + +inputDaysElement.value * 86400;
    };
    function action() {

        let totalSeconds = getTimeFromAllInputAndReturnInSeconds();

        (function convertToDays() {
            //console.log(getTimeFromAllInputAndReturnInSeconds());
            inputDaysElement.value = totalSeconds / 86400;
        })();

        (function convertToHours() {
            inputHoursElement.value = totalSeconds / 3600;
        })();

        (function convertToMinutes() {
            inputMinutesElement.value = totalSeconds / 60;
        })();

        (function convertToSeconds() {
            inputSecondsElement.value = totalSeconds;
        })();
    }

}