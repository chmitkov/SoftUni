function encodeAndDecodeMessages() {
    const btnEncode = document.getElementsByTagName('button')[0];
    btnEncode.addEventListener('click', encodeFunc);
    const btnDecode = document.getElementsByTagName('button')[1];
    btnDecode.addEventListener('click', decodeFunc);
    let textAreaElement = document.getElementsByTagName('textarea')[0];
    let secondTextAreaElement = document.getElementsByTagName('textarea')[1];


    function encodeFunc() {
        let text = textAreaElement.value;
        let result = '';
        for (let i = 0; i < text.length; i++) {
            result += String.fromCharCode(text.charCodeAt(i) + 1);
        }
        secondTextAreaElement.value = result;
        textAreaElement.value = '';
    }

    function decodeFunc() {
        let text = secondTextAreaElement.value;
        let result = '';
        for (let i = 0; i < text.length; i++) {
            result += String.fromCharCode(text.charCodeAt(i) - 1);
        }

        secondTextAreaElement.value = result;


    }
}