function lockedProfile() {
    for (const element of document.getElementsByTagName('button')) {
        element.addEventListener('click', showMore);
    }

    function showMore() {
        let parent = this.parentElement;
        let userLockRadioButton = parent.querySelector('input[type=radio]');
        if (!userLockRadioButton.checked) {
            let hiddenInfo = parent.getElementsByTagName('div')[0];
            let button = parent.getElementsByTagName('button')[0];
            hiddenInfo.style.display = 'block';
            button.innerText = 'Hide it';

            button.removeEventListener('click', showMore);
            button.addEventListener('click', hideIt);
        }
    }

    function hideIt() {
        let parent = this.parentElement;
        let userLockRadioButton = parent.querySelector('input[type=radio]');

        if (!userLockRadioButton.checked) {
            let hiddenInfo = parent.getElementsByTagName('div')[0];
            let button = parent.getElementsByTagName('button')[0];

            hiddenInfo.style.display = 'none';
            button.innerText = 'Show more';

            button.removeEventListener('click', hideIt);
            button.addEventListener('click', showMore);
        }
    }
}