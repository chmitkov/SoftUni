function addItem() {
    const ul = document.getElementById('items');
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.innerText = 'Delete';
    a.setAttribute('href', '#');
    a.addEventListener('click', deleteItem);
    const text = document.getElementById('newText').value;
    li.innerText = text + ' ';
    li.appendChild(a);
    ul.appendChild(li);

    function deleteItem() {
        this.parentElement.remove();
    }
}