function deleteByEmail() {

    const allTr = document.getElementsByTagName('tr');
    const searchedEmail = document.querySelector('body > label > input[type=text]')
        .value;
    let map = {};
    let  resultElement = document.getElementById('result');
    for (let i = 1; i < allTr.length; i++) {
        let tr = allTr[i];
        let email = tr.children[1].innerText;
        map[email] = tr;
    }

    if (Object.keys(map).includes(searchedEmail)) {
        resultElement.innerText = 'Deleted.';
        map[searchedEmail].remove();
    } else {
        resultElement.innerText = 'Not Found';
    }

}