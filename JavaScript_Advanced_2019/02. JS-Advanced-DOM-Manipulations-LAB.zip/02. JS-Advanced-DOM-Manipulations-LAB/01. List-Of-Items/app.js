function addItem() {
    const ul = document.getElementById('items');
    const li = document.createElement('li');
    const text = document.getElementById('newItemText').value;
    li.innerText = text;
    items.appendChild(li);

}