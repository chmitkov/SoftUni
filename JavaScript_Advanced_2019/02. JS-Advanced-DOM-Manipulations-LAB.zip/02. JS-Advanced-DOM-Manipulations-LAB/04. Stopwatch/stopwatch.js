function stopwatch() {

}