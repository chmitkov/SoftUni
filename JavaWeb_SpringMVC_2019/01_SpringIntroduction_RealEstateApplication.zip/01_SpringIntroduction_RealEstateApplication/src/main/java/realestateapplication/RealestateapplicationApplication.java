package realestateapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealestateapplicationApplication {

    public static void main(String[] args) {
        SpringApplication.run(RealestateapplicationApplication.class, args);
    }

}
