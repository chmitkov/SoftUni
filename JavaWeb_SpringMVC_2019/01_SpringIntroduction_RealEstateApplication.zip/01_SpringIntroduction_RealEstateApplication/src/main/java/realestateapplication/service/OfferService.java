package realestateapplication.service;

import realestateapplication.domain.models.service.OfferServiceModel;

public interface OfferService {

    void registerOffer(OfferServiceModel offerServiceModel);
}
