package org.ch.productshop.web.contollers;

import org.ch.productshop.domain.models.view.ProductViewModel;
import org.ch.productshop.domain.models.view.ShoppingCartItem;
import org.ch.productshop.service.ProductService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

import static org.ch.productshop.web.GlobalConstants.SHOPPING_CART_NAME;

@Controller
@RequestMapping("/cart")
public class CartController extends BaseController {

    private final ProductService productService;
    private final ModelMapper modelMapper;

    @Autowired
    public CartController(ProductService productService, ModelMapper modelMapper) {
        this.productService = productService;
        this.modelMapper = modelMapper;
    }

    @PostMapping("/add-product")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView addToCartConfirm(String id, int quantity, HttpSession httpSession) {

        this.initCart(httpSession);

        ProductViewModel productViewModel = this.modelMapper
                .map(this.productService.findProductById(id), ProductViewModel.class);

        ShoppingCartItem shoppingCartItem = new ShoppingCartItem();
        shoppingCartItem.setProductViewModel(productViewModel);
        shoppingCartItem.setQuantity(quantity);

        this.addItemToCart(shoppingCartItem, httpSession);

        return redirect("/home");
    }


    @GetMapping("/details")
    @PreAuthorize("isAuthenticated()")
    public ModelAndView cartDetails(ModelAndView modelAndView, HttpSession httpSession) {
        this.initCart(httpSession);
        modelAndView.addObject("total", this.calcTotal(httpSession));

        return view("shopping-cart/cart-details", modelAndView);
    }


    private void initCart(HttpSession httpSession) {
        if (httpSession.getAttribute(SHOPPING_CART_NAME) == null) {
            httpSession.setAttribute(SHOPPING_CART_NAME, new LinkedList<>());
        }
    }

    private void addItemToCart(ShoppingCartItem item, HttpSession httpSession) {
        for (ShoppingCartItem shoppingCartItem : (List<ShoppingCartItem>) httpSession.getAttribute(SHOPPING_CART_NAME)) {
            if (shoppingCartItem.getProductViewModel().getId()
                    .equals(item.getProductViewModel().getId())) {

                shoppingCartItem.setQuantity(shoppingCartItem.getQuantity() + item.getQuantity());
                return;
            }
        }

        ((List<ShoppingCartItem>) httpSession.getAttribute(SHOPPING_CART_NAME))
                .add(item);

    }

    private BigDecimal calcTotal(HttpSession httpSession) {
        List<ShoppingCartItem> list = (List<ShoppingCartItem>) httpSession.getAttribute("shopping-cart");

       return  list
                .stream()
                .map(i-> BigDecimal.valueOf(i.getQuantity() * 1.0).multiply(i.getProductViewModel().getPrice()))
                .reduce((a, b) -> a.add(b))
                .orElse(null);

    }
}
