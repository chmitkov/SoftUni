package org.ch.productshop.domain.models.view;

import org.ch.productshop.domain.entities.Product;
import org.ch.productshop.domain.entities.User;

import java.math.BigDecimal;
import java.time.LocalDate;

public class OrderViewModel {

    private Product product;
    private User user;
    private BigDecimal price;
    private LocalDate localDate;

    public OrderViewModel() {
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public LocalDate getLocalDate() {
        return localDate;
    }

    public void setLocalDate(LocalDate localDate) {
        this.localDate = localDate;
    }
}
