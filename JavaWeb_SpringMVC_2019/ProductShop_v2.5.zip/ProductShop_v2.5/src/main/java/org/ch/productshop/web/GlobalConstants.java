package org.ch.productshop.web;

public class GlobalConstants {
    public static final String VIEW_MODEL_OBJECT_NAME = "viewModel";
}
