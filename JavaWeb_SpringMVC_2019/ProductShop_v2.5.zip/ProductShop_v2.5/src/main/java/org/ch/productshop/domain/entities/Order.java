package org.ch.productshop.domain.entities;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;


@Entity
@Table(name = "orders")
public class Order extends BaseEntity{

    private Product product;
    private User user;
    private BigDecimal price;
    private LocalDate localDate;

    public Order() {
    }

    public Order(Product product, User user) {
        this.product = product;
        this.user = user;
    }

    public Order(Product product, User user, BigDecimal price, LocalDate localDate) {
        this.product = product;
        this.user = user;
        this.price = price;
        this.localDate = localDate;
    }

    @ManyToOne(targetEntity = Product.class)
    public Product getProduct() {
        return product;
    }


    public void setProduct(Product product) {
        this.product = product;
    }

    @ManyToOne(targetEntity = User.class)
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public LocalDate getLocalDate() {
        return localDate;
    }

    public void setLocalDate(LocalDate localDate) {
        this.localDate = localDate;
    }
}
