package org.ch.productshop.service;

import org.ch.productshop.domain.entities.Order;
import org.ch.productshop.domain.entities.Product;
import org.ch.productshop.domain.entities.User;
import org.ch.productshop.domain.models.service.OrderServiceModel;
import org.ch.productshop.repository.OrderRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final ProductService productService;
    private final UserService userService;
    private final ModelMapper modelMapper;

    @Autowired
    public OrderServiceImpl(OrderRepository orderRepository, ProductService productService, UserService userService, ModelMapper modelMapper) {
        this.orderRepository = orderRepository;
        this.productService = productService;
        this.userService = userService;
        this.modelMapper = modelMapper;
    }

    @Override
    public void createOrder(OrderServiceModel orderServiceModel) {
        User user = this.modelMapper
                .map(this.userService.findUserByUsername(orderServiceModel.getUsername()), User.class);

        Product product = this.modelMapper
                .map(this.productService
                        .findProductById(orderServiceModel.getProductId()), Product.class);

        Order order = new Order(product, user, orderServiceModel.getPrice(), orderServiceModel.getDate());

        this.orderRepository.save(order);
    }

    @Override
    public List<Order> findAllOrdersByUserUsername(String username) {
        return this.orderRepository
                .findAllByUserUsername(username);
    }
}
