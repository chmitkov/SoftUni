package org.ch.productshop.service;


import org.ch.productshop.domain.entities.Order;
import org.ch.productshop.domain.models.service.OrderServiceModel;

import java.util.List;

public interface OrderService {

    void createOrder(OrderServiceModel orderServiceModel);

    List<Order> findAllOrdersByUserUsername(String username);
}
