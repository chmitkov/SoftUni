package org.ch.productshop.service;

import org.ch.productshop.domain.entities.Order;
import org.ch.productshop.domain.entities.Product;
import org.ch.productshop.domain.entities.User;
import org.ch.productshop.domain.models.service.OrderServiceModel;
import org.ch.productshop.repository.OrderRepository;
import org.ch.productshop.validations.ProductValidationService;
import org.ch.productshop.validations.UserValidationService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final ProductService productService;
    private final UserService userService;
    private final ModelMapper modelMapper;
    private final UserValidationService userValidationService;
    private final ProductValidationService productValidationService;

    @Autowired
    public OrderServiceImpl(OrderRepository orderRepository, ProductService productService, UserService userService, ModelMapper modelMapper, UserValidationService userValidationService, ProductValidationService productValidationService) {
        this.orderRepository = orderRepository;
        this.productService = productService;
        this.userService = userService;
        this.modelMapper = modelMapper;
        this.userValidationService = userValidationService;
        this.productValidationService = productValidationService;
    }

    @Override
    public void createOrder(OrderServiceModel orderServiceModel) throws Exception {
        User user = this.modelMapper
                .map(this.userService.findUserByUsername(orderServiceModel.getUsername()), User.class);

        if(!this.userValidationService.isValid(user)){
            throw new Exception();
        }

        Product product = this.modelMapper
                .map(this.productService
                        .findProductById(orderServiceModel.getProductId()), Product.class);

        if(!productValidationService.isValid(product)){
            throw new Exception();
        }

        Order order = new Order(product, user, orderServiceModel.getPrice(), orderServiceModel.getDate());

        this.orderRepository.save(order);
    }

    @Override
    public List<Order> findAllOrdersByUserUsername(String username) {
        return this.orderRepository
                .findAllByUserUsernameOrderByLocalDateDesc(username);
    }

    @Override
    public List<Order> findAll() {
        return this.orderRepository
                .findAll();
    }
}
