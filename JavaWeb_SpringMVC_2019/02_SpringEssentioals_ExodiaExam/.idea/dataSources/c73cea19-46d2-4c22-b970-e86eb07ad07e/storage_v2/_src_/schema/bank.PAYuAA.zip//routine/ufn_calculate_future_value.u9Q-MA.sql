create
    definer = root@localhost function ufn_calculate_future_value(init_sum decimal(19, 4), rate decimal(19, 4), years int) returns decimal
BEGIN 
	DECLARE result DECIMAL(8,2);
	SET result = init_sum * pow((1+rate), years);
    RETURN result;
END;

