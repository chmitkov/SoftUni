create
    definer = root@localhost procedure usp_deposit_money(IN acc_id int, IN money_amount decimal(19, 4))
BEGIN
	START TRANSACTION;
    IF money_amount < 0
    THEN ROLLBACK;
    ELSE 
		UPDATE accounts AS a 
        SET a.balance = a.balance + money_amount
        WHERE a.account_holder_id = acc_id;
    END IF;    
END;

