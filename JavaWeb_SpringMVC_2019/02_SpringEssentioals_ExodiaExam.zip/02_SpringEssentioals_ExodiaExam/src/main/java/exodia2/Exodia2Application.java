package exodia2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exodia2Application {

    public static void main(String[] args) {
        SpringApplication.run(Exodia2Application.class, args);
    }

}
