create
    definer = root@localhost procedure usp_get_holders_with_balance_higher_than(IN num decimal(19, 4))
BEGIN
	SELECT ah.first_name, ah.last_name
    FROM account_holders AS ah 
    JOIN accounts AS a 
    ON ah.id = a.account_holder_id
    GROUP BY a.account_holder_id
    HAVING SUM(a.balance) > num 
    ORDER BY ah.first_name, ah.last_name, a.id;
END;

