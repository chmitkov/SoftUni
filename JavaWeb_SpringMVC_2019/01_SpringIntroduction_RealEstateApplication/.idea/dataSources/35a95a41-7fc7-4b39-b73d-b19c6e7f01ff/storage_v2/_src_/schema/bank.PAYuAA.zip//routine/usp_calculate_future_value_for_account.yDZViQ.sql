create
    definer = root@localhost procedure usp_calculate_future_value_for_account(IN searched_id int, IN rate decimal(19, 4))
BEGIN 
	DECLARE total_amount DECIMAL(19,4);
    DECLARE curr_balance DECIMAL(19,4);
    SET curr_balance = (
		SELECT SUM(balance) 
        FROM accounts 
        WHERE account_holder_id = searched_id 
        GROUP BY account_holder_id); 
    SET total_amount = ufn_calculate_future_value(curr_balance, rate, 5);
    SELECT ah.id, ah.first_name, ah.last_name, curr_balance, total_amount
    FROM accounts_holders AS ah;
END;

