package problem_5_BorderControl;

public interface HavingId {
    String getId();
}
