package problem_3_Ferrari;

public interface Car {
    String hitBrakes();
    String hitGas();
}
