package problem_6_BirthdayCelebrations;

public interface HavingId {
    String getId();
}
