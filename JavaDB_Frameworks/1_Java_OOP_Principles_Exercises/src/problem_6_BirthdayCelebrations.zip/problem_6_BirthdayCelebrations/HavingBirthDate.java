package problem_6_BirthdayCelebrations;

import java.util.Date;

public interface HavingBirthDate {
    String getDate();
}
