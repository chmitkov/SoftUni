create view v_employees_job_titles as
  select concat(`soft_uni`.`employees`.`first_name`, ' ', ifnull(`soft_uni`.`employees`.`middle_name`, ''), ' ',
                `soft_uni`.`employees`.`last_name`) AS `full_name`, `soft_uni`.`employees`.`job_title` AS `job_title`
  from `soft_uni`.`employees`;

