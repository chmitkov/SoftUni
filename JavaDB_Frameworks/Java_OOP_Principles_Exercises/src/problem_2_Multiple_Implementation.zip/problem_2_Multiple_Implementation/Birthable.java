package problem_2_Multiple_Implementation;

public interface Birthable {
    String getBirthdate();
}
