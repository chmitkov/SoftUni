package problem_2_Multiple_Implementation;

public interface Identifiable {
    String getId();
}
