package problem_1_DefineAnInterface;

public interface Person {
    String getName();
    int getAge();
}
