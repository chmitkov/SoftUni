package app.ccb.util;

public interface ValidationUtil {

    <E> boolean isValid(E entity);
}
