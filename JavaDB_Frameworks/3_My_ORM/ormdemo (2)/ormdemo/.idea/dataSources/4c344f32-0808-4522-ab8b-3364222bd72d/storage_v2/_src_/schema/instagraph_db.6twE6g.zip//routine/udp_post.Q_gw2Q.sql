create procedure udp_post(IN username varchar(30), IN password varchar(30), IN caption varchar(255),
                          IN path     varchar(255))
  BEGIN
	IF ((SELEcT u.password FROM users u WHERE u.username = username) <> password) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Password is incorrect!';
	ELSEIF ((SELECT count(p.id) FROM pictures p WHERE p.path = path) = 0) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The picture does not exist!';
	ELSE
		INSERT INTO posts(caption, user_id, picture_id)
        VALUES
        (
			caption, 
			(SELECT u.id FROM users u WHERE u.username = username), 
			(SELECT p.id FROM pictures p WHERE p.path = path)
        );
    END IF;
END;

