create procedure usp_get_towns_starting_with(IN input_str varchar(50))
  BEGIN
	DECLARE town_wildcard VARCHAR(50);
    SET town_wildcard := concat(input_str, '%');
    
    SELECT t.name
    FROM towns t
    WHERE lower(t.name) LIKE lower(concat(input_str, '%'))
    ORDER BY t.name;
END;

