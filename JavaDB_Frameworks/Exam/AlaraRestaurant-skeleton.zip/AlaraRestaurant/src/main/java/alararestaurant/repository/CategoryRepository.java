package alararestaurant.repository;

public interface CategoryRepository {

}
