package opinionPoll;

public class Person1 {
    private String name;
    private int age;

    public Person1() {
        this("No name", 1);
    }

    public Person1(int age) {
        this("No name", age);
    }

    public Person1(String name, int age) {
        this.age = age;
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return this.age;
    }

    public void setAge(int age) {
        this.age = age;
    }


}
