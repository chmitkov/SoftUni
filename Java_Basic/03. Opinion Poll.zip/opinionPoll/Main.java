package opinionPoll;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Map<String, Person1> map = new TreeMap<>();
        int num = Integer.parseInt(br.readLine());

        while (num-- > 0) {
            String[] commands = br.readLine().split("\\s+");

            String name = commands[0];
            int age = Integer.parseInt(commands[1]);
            Person1 currPerson = new Person1(name,age);
            map.put(name,currPerson);
        }

        map.entrySet().stream()
                .filter(x->x.getValue().getAge()>30)
                .forEach(x-> System.out.printf("%s - %d%n",x.getValue().getName(),x.getValue().getAge()));
    }
}
