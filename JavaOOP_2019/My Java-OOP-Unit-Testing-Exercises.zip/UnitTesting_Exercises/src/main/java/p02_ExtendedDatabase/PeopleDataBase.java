package p02_ExtendedDatabase;

import javax.naming.OperationNotSupportedException;
import java.util.ArrayList;
import java.util.List;

public class PeopleDataBase {
    private List<Person> persons;

    public PeopleDataBase() {
        this.persons = new ArrayList<>();
    }

    public void add(Person person) throws OperationNotSupportedException {
        if (containsIdInDatabase(person.getId())
                || Integer.valueOf(person.getId()) < 0
                || this.persons.size() == 16) {
            throw new OperationNotSupportedException();
        }
        this.persons.add(person);
    }

    public void remove() throws OperationNotSupportedException {
        if (this.persons.size() == 0) {
            throw new OperationNotSupportedException();
        }
        this.persons.remove(this.persons.size() - 1);
    }

//    public void remove(Person person) throws OperationNotSupportedException {
//        if (!this.persons.contains(person)) {
//            throw new OperationNotSupportedException();
//        }
//        this.persons.remove(person);
//    }

    public Person findByUserName(String name) throws OperationNotSupportedException {
        if (name == null) {
            throw new OperationNotSupportedException();
        }
        Person searchedPerson = this.persons.stream()
                .filter(x -> x.getName().equals(name))
                .findFirst()
                .orElse(null);
        if (searchedPerson == null) {
            throw new OperationNotSupportedException();
        }
        return searchedPerson;
    }

    public Person findById(String id) throws OperationNotSupportedException {
        Person searchedPerson = this.persons.stream()
                .filter(x -> x.getId().equals(id))
                .findFirst()
                .orElse(null);
        if (searchedPerson == null) {
            throw new OperationNotSupportedException();
        }
        return searchedPerson;
    }


    private boolean containsIdInDatabase(String id) {
        return this.persons.stream().anyMatch(x -> x.getId().equals(id));
    }

}
