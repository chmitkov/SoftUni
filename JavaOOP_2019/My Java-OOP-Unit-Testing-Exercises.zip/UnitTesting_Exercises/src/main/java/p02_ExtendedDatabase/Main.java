package p02_ExtendedDatabase;

import javax.naming.OperationNotSupportedException;

public class Main {
    public static void main(String[] args) throws OperationNotSupportedException {
        PeopleDataBase dataBase = new PeopleDataBase();

        dataBase.add(new Person("1", "Name"));

        System.out.println(dataBase.findById("1"));

        dataBase.remove();

        System.out.println();
    }
}
