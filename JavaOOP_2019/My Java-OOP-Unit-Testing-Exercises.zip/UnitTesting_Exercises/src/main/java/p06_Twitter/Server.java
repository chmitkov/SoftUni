package p06_Twitter;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Server {
    private Set<String> database;

    public Server() {
        this.database = new HashSet<>();
    }

    public void addMessageToDatabase(String... message) {
        this.database.addAll(Arrays.asList(message));
    }
}
