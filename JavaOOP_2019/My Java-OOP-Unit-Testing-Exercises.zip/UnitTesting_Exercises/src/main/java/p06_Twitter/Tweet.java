package p06_Twitter;

public interface Tweet {
    String retrieve();
}
