package p06_Twitter;

public interface Client {
    void retrieveMessage(Tweet tweet);
}
