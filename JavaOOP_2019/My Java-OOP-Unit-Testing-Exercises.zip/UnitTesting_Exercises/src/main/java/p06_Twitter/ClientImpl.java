package p06_Twitter;

public class ClientImpl implements Client {
    private String message;
    private Server server;

    public ClientImpl(Server server) {
        this.server = new Server();
    }

    @Override
    public void retrieveMessage(Tweet tweet) {
        this.message = tweet.retrieve();
        this.server.addMessageToDatabase(this.message);
    }


}
