package p06_Twitter;

public class TweetImpl implements Tweet {

    private String message;

    public TweetImpl(String message) {
        this.message = message;
    }

    @Override
    public String retrieve() {
        return this.message;
    }
}
