package p03_IteratorTest;

import javax.naming.OperationNotSupportedException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


public class ListIterator {

    private List<String> elements;
    private int index;

    public ListIterator(Collection<String> elements) throws OperationNotSupportedException {
        if (elements == null|| elements.isEmpty()) {
            throw new OperationNotSupportedException("Invalid Operation!");
        }
        this.elements = new ArrayList<>();
        this.elements.addAll(elements);
        this.index = 0;
    }

    public boolean move() throws OperationNotSupportedException {
        if(!this.hasNext()){
            throw new OperationNotSupportedException("Invalid Operation!");
        }
        this.index++;
        return true;
    }

    public String print() {
        return this.elements.get(index);
    }

    public boolean hasNext() {
        return index < elements.size() - 1;
    }
}
