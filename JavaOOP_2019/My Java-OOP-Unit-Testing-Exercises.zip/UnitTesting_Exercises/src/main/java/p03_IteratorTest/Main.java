package p03_IteratorTest;

import javax.naming.OperationNotSupportedException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws IOException, OperationNotSupportedException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String[] createCommand = br.readLine().split("\\s+");
        Collection<String> collection = Arrays.stream(createCommand)
                .skip(1).collect(Collectors.toList());
        ListIterator listIterator = null;
        try{
            listIterator = new ListIterator(collection);
        }catch (OperationNotSupportedException e){
            System.out.println(e.getMessage());
            return;
        }
        String line;

        while (!"END".equalsIgnoreCase(line = br.readLine())) {
            String[] commands = line.split("\\s+");

            switch (commands[0]) {
                case "HasNext":
                    System.out.println(listIterator.hasNext());
                    break;
                case "Move":
                    System.out.println(listIterator.move());
                    break;
                case "Print":
                    System.out.println(listIterator.print());
                    break;
            }
        }
    }
}
