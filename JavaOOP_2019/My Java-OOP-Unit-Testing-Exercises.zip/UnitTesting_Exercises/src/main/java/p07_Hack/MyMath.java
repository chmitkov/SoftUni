package p07_Hack;

public class MyMath {

    public MyMath(){
    }

}
