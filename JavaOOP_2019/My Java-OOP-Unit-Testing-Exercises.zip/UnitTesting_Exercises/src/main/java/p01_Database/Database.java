package p01_Database;

import javax.naming.OperationNotSupportedException;

public class Database {
    private int[] numbers;

    public Database(int[] numbers) throws OperationNotSupportedException {
        if (numbers.length > 16) {
            throw new OperationNotSupportedException();
        }

        this.numbers = numbers;
    }

    public void add(int element) throws OperationNotSupportedException {
        if (this.numbers.length + 1 > 16) {
            throw new OperationNotSupportedException();
        }
        int[] newArray = new int[this.numbers.length + 1];
        for (int i = 0; i < this.numbers.length; i++) {

            newArray[i] = this.numbers[i];
        }
        newArray[newArray.length - 1] = element;

        this.numbers = newArray;
    }

    public void remove() throws OperationNotSupportedException {
        if (this.numbers.length == 0) {
            throw new OperationNotSupportedException();
        }
        int[] newArray = new int[this.numbers.length - 1];
        System.arraycopy(this.numbers, 0, newArray, 0, newArray.length);
        this.numbers = newArray;
    }

    public int[] fetch() {
        return this.numbers;
    }

}
