package p01_Database;

import javax.naming.OperationNotSupportedException;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws OperationNotSupportedException {
        Database database = new Database(new int[]{1, 2, 3, 4, 5});
        database.add(9);
        Arrays.stream(database.fetch()).forEach(System.out::println);
        System.out.println("============");
        database.remove();
        Arrays.stream(database.fetch()).forEach(System.out::println);
        System.out.println("============");
    }
}
