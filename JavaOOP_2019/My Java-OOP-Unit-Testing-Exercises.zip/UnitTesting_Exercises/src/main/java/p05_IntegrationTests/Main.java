package p05_IntegrationTests;

public class Main {
    public static void main(String[] args) {
        User user = new User("User");
        User user_2 = new User("User2");
        Category category = new Category("MainCategory");
        Category subCategory = new Category("SubCategory");
        Category subCategory_2 = new Category("SubCategory2");

        category.addSubcategory(subCategory);

        user.addCategory(category);

        subCategory_2.addUser(user_2);

        category.addSubcategory(subCategory_2);

        category.removeCategory(subCategory_2);

        System.out.println();
    }
}
