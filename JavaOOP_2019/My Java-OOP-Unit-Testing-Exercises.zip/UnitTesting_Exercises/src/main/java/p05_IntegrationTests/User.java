package p05_IntegrationTests;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class User {
    private String name;
    private Set<Category> categorySet;

    public User(String name) {
        this.name = name;
        this.categorySet = new HashSet<>();
    }

    public void addCategory(Category category) {
        category.addUser(this);
        this.categorySet.add(category);
    }

    public void removeCategory(Category category) {
        this.categorySet.remove(category);
    }

    public Set<Category> getCategorySet() {
        return Collections.unmodifiableSet(this.categorySet);
    }

    public void onlyAddCategoryInSet(Category category) {
        this.categorySet.add(category);
    }
}
