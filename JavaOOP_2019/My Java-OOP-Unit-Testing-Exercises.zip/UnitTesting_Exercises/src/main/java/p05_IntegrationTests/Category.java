package p05_IntegrationTests;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Category {
    private String name;
    private Set<User> userSet;
    private Set<Category> subCategorySet;

    public Category(String name) {
        this.name = name;
        this.userSet = new HashSet<>();
        this.subCategorySet = new HashSet<>();
    }

    public void addUser(User user) {
        this.userSet.add(user);
        user.onlyAddCategoryInSet(this);
    }

    public void addSubcategory(Category subCategory) {
        this.subCategorySet.add(subCategory);
        this.userSet.addAll(subCategory.getUserSet());
    }

    public void removeCategory(Category category) {
        this.subCategorySet.remove(category);

        for (User user : userSet) {
            if(user.getCategorySet().contains(category)){
                user.removeCategory(category);
                this.userSet.remove(user);
            }
        }
    }

    public String getName() {
        return this.name;
    }

    public Set<User> getUserSet() {
        return Collections.unmodifiableSet(this.userSet);
    }
}
