package p04_BubbleSortTest;

public class Main {
    public static void main(String[] args) {
        BubbleSort bubbleSort = new BubbleSort();
        bubbleSort.add(5);
        bubbleSort.add(6);
        bubbleSort.add(1);
        bubbleSort.add(3);
        System.out.println(bubbleSort);
        bubbleSort.sort();
        System.out.println(bubbleSort);
    }
}
