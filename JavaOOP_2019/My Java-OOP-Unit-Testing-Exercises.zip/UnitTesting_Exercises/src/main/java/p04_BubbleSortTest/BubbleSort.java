package p04_BubbleSortTest;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BubbleSort {
    private List<Integer> numbers;

    public BubbleSort() {
        this.numbers = new ArrayList<>();
    }

    public void add(int number) {
        this.numbers.add(number);
    }

    public void sort() {
        if (this.numbers.size() > 1) {
            int loops = 0;
            boolean isSorted = false;

            while (loops++ < this.numbers.size() && !isSorted) {
                isSorted = true;
                for (int i = 1; i < this.numbers.size() + 1 - loops; i++) {
                    if (this.numbers.get(i - 1) > this.numbers.get(i)) {
                        int temp = this.numbers.get(i - 1);
                        this.numbers.set(i - 1, this.numbers.get(i));
                        this.numbers.set(i, temp);
                        isSorted = false;
                    }
                }
            }
        }
    }

    @Override
    public String toString() {
        return this.numbers.stream()
                .map(String::valueOf)
                .collect(Collectors.joining(", "));
    }
}
