package p01_Database;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import javax.naming.OperationNotSupportedException;

import java.lang.reflect.Field;

import static org.junit.Assert.*;

public class DatabaseTest {

    private static final int TEST_INT = 9;
    private static final String WRONG_RESULT_MESSAGE = "Wrong result from method %s!";

    private Database database;

    @Before
    public void testSetUp() throws Exception {
        this.database = new Database(new int[]{1, 2, 3, 4, 5});
    }

    @Test
    public void testAdd() throws OperationNotSupportedException, NoSuchFieldException, IllegalAccessException {
        this.database.add(TEST_INT);
        Field numsField = this.database.getClass().getDeclaredField("numbers");
        numsField.setAccessible(true);
        int[] numbers = (int[]) numsField.get(this.database);
        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "add")
                , TEST_INT, numbers[numbers.length - 1]);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void testAddMethodException() throws OperationNotSupportedException {
        this.database = new Database(new int[16]);
        this.database.add(TEST_INT);
    }

    @Test
    public void testRemove() throws OperationNotSupportedException, NoSuchFieldException, IllegalAccessException {
        this.database.remove();
        Field numsField = this.database.getClass().getDeclaredField("numbers");
        numsField.setAccessible(true);
        int[] numbers = (int[]) numsField.get(this.database);
        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "remove")
                , 4, numbers.length);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void testRemoveMethodException() throws OperationNotSupportedException {
        this.database = new Database(new int[0]);
        this.database.remove();
    }

    @Test
    public void testFetch() throws NoSuchFieldException, IllegalAccessException {
        int[] result = this.database.fetch();
        Field numsField = this.database.getClass().getDeclaredField("numbers");
        numsField.setAccessible(true);
        int[] numbers = (int[]) numsField.get(this.database);
        Assert.assertArrayEquals(result, numbers);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void testConstructor() throws OperationNotSupportedException {
        this.database = new Database(new int[17]);
    }
}