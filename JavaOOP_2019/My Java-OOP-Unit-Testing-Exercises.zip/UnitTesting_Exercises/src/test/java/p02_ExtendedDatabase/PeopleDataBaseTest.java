package p02_ExtendedDatabase;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import javax.naming.OperationNotSupportedException;

import java.lang.reflect.Field;
import java.util.List;

import static org.junit.Assert.*;

public class PeopleDataBaseTest {

    private static final String DEFAULT_ID = "9";
    private static final String DEFAULT_NAME = "Name";
    private static final String WRONG_RESULT = "Wrong result from method %s!";
    private static final String NEGATIVE_VALUE = "-1";

    private PeopleDataBase dataBase;
    private Person person;
    private List<Person> personList;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws Exception {
        this.dataBase = new PeopleDataBase();

        this.person = Mockito.mock(Person.class);
        Mockito.when(person.getId()).thenReturn(DEFAULT_ID);
        Mockito.when(person.getName()).thenReturn(DEFAULT_NAME);

        Field field = this.dataBase.getClass().getDeclaredField("persons");
        field.setAccessible(true);
        this.personList = (List<Person>) field.get(this.dataBase);
    }

    @Test
    public void add() throws OperationNotSupportedException, NoSuchFieldException, IllegalAccessException {
        this.dataBase.add(person);

        Assert.assertEquals(String.format(WRONG_RESULT, "add"),
                this.personList.get(0).getId(), DEFAULT_ID);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void addMethodException() throws OperationNotSupportedException {
        for (int i = 0; i < 17; i++) {
            this.dataBase.add(this.person);
        }
    }

    @Test(expected = OperationNotSupportedException.class)
    public void addMethodExceptionWithNegativeNumber() throws OperationNotSupportedException {
        Mockito.when(this.person.getId()).thenReturn(NEGATIVE_VALUE);
        this.dataBase.add(this.person);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void addMethodExceptionWithExistedPerson() throws OperationNotSupportedException {
        for (int i = 0; i < 2; i++) {
            this.dataBase.add(this.person);
        }
    }

    @Test
    public void remove() throws OperationNotSupportedException {
        this.personList.add(this.person);
        this.dataBase.remove();
        Assert.assertEquals(String.format(WRONG_RESULT, "remove"),
                0, this.personList.size());
    }

    @Test(expected = OperationNotSupportedException.class)
    public void removeMethodException() throws OperationNotSupportedException {
        this.dataBase.remove();
    }

    @Test
    public void findByUserName() throws OperationNotSupportedException {
        this.personList.add(this.person);
        Person searchedPerson = this.dataBase.findByUserName(DEFAULT_NAME);
        Assert.assertEquals(String.format(WRONG_RESULT, "findByUserName"),
                searchedPerson.getName(), DEFAULT_NAME);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void findByUserNameMethodException() throws OperationNotSupportedException {
        this.dataBase.findByUserName(DEFAULT_NAME);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void findByUserNameMethodExceptionWithNullParameter() throws OperationNotSupportedException {
        this.dataBase.findByUserName(null);
    }

    @Test(expected = OperationNotSupportedException.class)
    public void findByUserNameMethodExceptionWithUpperCaseUserName() throws OperationNotSupportedException {
        this.personList.add(this.person);
        this.dataBase.findByUserName(DEFAULT_NAME.toUpperCase());
    }

    @Test
    public void findById() throws OperationNotSupportedException {
        this.personList.add(this.person);
        Person searchedPerson = this.dataBase.findById(DEFAULT_ID);
        Assert.assertEquals(String.format(WRONG_RESULT, "findById"),
                DEFAULT_ID, searchedPerson.getId());
    }

    @Test(expected = OperationNotSupportedException.class)
    public void findByIdMethodException() throws OperationNotSupportedException {
        this.dataBase.findById(DEFAULT_ID);
    }
}