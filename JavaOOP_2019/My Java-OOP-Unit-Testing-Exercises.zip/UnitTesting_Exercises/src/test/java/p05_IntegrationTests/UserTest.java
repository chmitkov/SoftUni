package p05_IntegrationTests;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.Set;

import static org.junit.Assert.*;

public class UserTest {

    private static final String USER_NAME = "UserName";
    private static final String DEFAULT_CATEGORY_NAME = "CategoryName";
    private static final String WRONG_RESULT_MESSAGE = "Wrong result from method %s";
    private static final String EXPECTING_RESULT_FROM_GET_CATEGORY_SET = "UnmodifiableSet";
    private static final int ONE = 1;

    private User user;
    private Category category;
    private Set<Category> categorySet;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws Exception {
        this.user = new User(USER_NAME);
        this.category = Mockito.mock(Category.class);
        Field categorySetField = this.user.getClass()
                .getDeclaredField("categorySet");
        categorySetField.setAccessible(true);
        this.categorySet = (Set<Category>) categorySetField.get(this.user);
    }

    @Test
    public void addCategory() throws NoSuchFieldException, IllegalAccessException {
        this.user.addCategory(this.category);
        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "add"),
                ONE, this.categorySet.size());
    }

    @Test
    public void removeCategory() {
        Mockito.when(this.category.getName()).thenReturn(DEFAULT_CATEGORY_NAME);
        this.categorySet.add(this.category);
        this.user.removeCategory(category);

        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "removeCategory"),
                0, this.categorySet.size());
    }

    @Test
    public void getCategorySet() throws NoSuchMethodException {
        Set<Category> methodResult = this.user.getCategorySet();
        String nameOfMethodResultClass = methodResult.getClass().getSimpleName();

        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "getCategorySet"),
                EXPECTING_RESULT_FROM_GET_CATEGORY_SET, nameOfMethodResultClass);
    }
}