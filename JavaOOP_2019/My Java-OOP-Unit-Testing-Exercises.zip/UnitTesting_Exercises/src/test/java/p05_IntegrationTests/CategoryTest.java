package p05_IntegrationTests;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.Set;

public class CategoryTest {

    private static final String DEFAULT_CATEGORY_NAME = "CategoryName";
    private static final String DEFAULT_USER_NAME = "UserName";
    private static final String DEFAULT_SUBCATEGORY_NAME = "SubCategoryName";
    private static final String WRONG_RESULT_MESSAGE = "Wrong result from method %s";
    private static final String EXPECTING_RESULT_FROM_GET_USER_SET = "UnmodifiableSet";
    private static final int ONE = 1;

    private Category category;
    private User user;
    private Set<User> userSet;
    private Set<Category> subCategorySet;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws Exception {
        this.category = new Category(DEFAULT_CATEGORY_NAME);
        this.user = Mockito.mock(User.class);

        Field fieldUserSet = this.category.getClass().getDeclaredField("userSet");
        fieldUserSet.setAccessible(true);
        this.userSet = (Set<User>) fieldUserSet.get(this.category);

        Field fieldSubCategorySet = this.category.getClass().getDeclaredField("subCategorySet");
        fieldSubCategorySet.setAccessible(true);
        this.subCategorySet = (Set<Category>) fieldSubCategorySet.get(this.category);
    }

    @Test
    public void addUser() {
        this.category.addUser(this.user);
        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "addUser"),
                ONE, this.userSet.size());
    }

    @Test
    public void addSubcategory() {
        Category subcategory = new Category(DEFAULT_SUBCATEGORY_NAME);
        subcategory.addUser(this.user);
        this.category.addSubcategory(subcategory);

        Assert.assertTrue(String.format(WRONG_RESULT_MESSAGE, "addSubCategory"),
                this.subCategorySet.contains(subcategory));

        Assert.assertTrue(String.format(WRONG_RESULT_MESSAGE, "addSubcategory"),
                this.userSet.contains(this.user));
    }

    @Test
    public void removeCategory() {
        Category subcategory = new Category(DEFAULT_SUBCATEGORY_NAME);
        User newUser = new User(DEFAULT_USER_NAME);
        subcategory.addUser(newUser);
        this.subCategorySet.add(subcategory);
        this.userSet.add(newUser);

        this.category.removeCategory(subcategory);

        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "removeSubcategory"),
                0, this.subCategorySet.size());

        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "removeSubcategory"),
                0, this.userSet.size());
    }

    @Test
    public void getName() {
        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "getName"),
                DEFAULT_CATEGORY_NAME, this.category.getName());
    }

    @Test
    public void getUserSet() {
        Set<User> methodResult = this.category.getUserSet();
        String nameOfMethodResultClass = methodResult.getClass().getSimpleName();

        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "getCategorySet"),
                EXPECTING_RESULT_FROM_GET_USER_SET, nameOfMethodResultClass);
    }
}