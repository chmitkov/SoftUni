package p03_IteratorTest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.*;

public class ListIteratorTest {

    private static final String WRONG_RESULT = "Wrong result from method %s!";
    private static final int EXPECTED_RESULT = 1;

    private ListIterator listIterator;
    private Field fieldIndex;

    @Before
    public void setUp() throws Exception {
        List<String> collection = new ArrayList<String>() {{
            add("1");
            add("2");
            add("3");
        }};
        this.listIterator = new ListIterator(collection);
        Field field = this.listIterator.getClass().getDeclaredField("index");
        field.setAccessible(true);
        this.fieldIndex = field;
    }

    @Test
    public void move() throws OperationNotSupportedException, IllegalAccessException {
        this.listIterator.move();
        Assert.assertEquals(String.format(WRONG_RESULT, "move"),
                EXPECTED_RESULT, this.fieldIndex.get(this.listIterator));
    }

    @Test(expected = OperationNotSupportedException.class)
    public void moveMethodException() throws OperationNotSupportedException {
        for (int i = 0; i < 4; i++) {
            this.listIterator.move();
        }
    }

    @Test
    public void print() throws OperationNotSupportedException {
        String result = this.listIterator.print();
        Assert.assertEquals(String.format(WRONG_RESULT, "print"),
                String.valueOf(EXPECTED_RESULT), result);
    }

    @Test
    public void hasNext() {
        assertTrue(String.format(WRONG_RESULT, "hasNext"), this.listIterator.hasNext());
    }
}