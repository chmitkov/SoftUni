package p04_BubbleSortTest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

public class BubbleSortTest {

    private static final int TEST_VALUE = 9;
    private static final String WRONG_RESULT_MESSAGE = "Wrong result from method %s!";
    private static final List<Integer> EXPECTED_RESULT = Arrays.asList(1, 2, 3);

    private BubbleSort bubbleSort;
    private List<Integer> numbers;

    @Before
    public void setUp() throws Exception {
        this.bubbleSort = new BubbleSort();
        Field field = this.bubbleSort.getClass().getDeclaredField("numbers");
        field.setAccessible(true);
        this.numbers = (List<Integer>) field.get(this.bubbleSort);
    }

    @Test
    public void add() {
        this.bubbleSort.add(TEST_VALUE);

        assertEquals(String.format(WRONG_RESULT_MESSAGE, "add"),
                TEST_VALUE, (int) this.numbers.get(0));

    }

    @Test
    public void sort() {
        for (int i = 3; i > 0; i--) {
            this.numbers.add(i);
        }
        this.bubbleSort.sort();
        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "sort"),
                this.numbers, EXPECTED_RESULT);
    }

    @Test
    public void sortWithOneArgumentCollection() {
        this.bubbleSort.add(TEST_VALUE);
        this.bubbleSort.sort();
        Assert.assertEquals(String.format(WRONG_RESULT_MESSAGE, "sort"),
                this.numbers, Collections.singletonList(9));
    }
}