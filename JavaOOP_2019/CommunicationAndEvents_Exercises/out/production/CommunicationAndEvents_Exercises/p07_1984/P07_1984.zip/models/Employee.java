package models;

import annotations.Setter;

public class Employee extends Entity {

    private String name;
    private int income;

    public Employee(String id, String name, int income) {
        super(id);
        this.name = name;
        this.income = income;
    }

    public String getName() {
        return name;
    }

    @Setter(fieldName = "name", fieldType = "String")
    public void setName(String newValue) {
        String oldValue = this.name;
        this.name = newValue;
        this.fieldChanged("name", oldValue, newValue);
    }

    public double getIncome() {
        return income;
    }

    @Setter(fieldName = "income", fieldType = "int")
    public void setIncome(int income) {
        int oldValue = this.income;
        this.income = income;
        this.fieldChanged("income", oldValue, income);
    }

    private <T> void fieldChanged(String filedName, T oldValue, T newValue) {
        Class<?> employeeClass = Employee.class;
        super.fieldChanged(employeeClass, filedName, oldValue, newValue);
    }
}
