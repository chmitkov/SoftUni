package models;

import interfaces.Event;
import interfaces.Identifiable;
import interfaces.Observable;
import interfaces.Observer;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

abstract class Entity implements Observable, Identifiable {

    private List<Observer> observers;
    private String id;

    Entity(String id) {
        this.id = id;
        this.observers = new ArrayList<>();
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public <T> void triggerEvent(Field field, T oldValue, T newValue) {
        Event<T> event = new ChangeEvent<T>(this, field, oldValue, newValue);
        for (Observer observer : observers) {
            observer.update(event);
        }
    }

    @Override
    public void registerObserver(Observer observer) {
        this.observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        this.observers.remove(observer);
    }

    <T> void fieldChanged(Class<?> fieldClass, String filedName, T oldValue, T newValue) {
        try {
            Field field = fieldClass.getDeclaredField(filedName);
            this.triggerEvent(field, oldValue, newValue);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
    }

}
