package core;

import annotations.Setter;
import interfaces.*;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

public class ProgramDispatcher implements Dispatcher {

    private Data data;
    private Reader reader;
    private Writer writer;
    private ObserverCreator observerCreator;
    private ObservableCreator observableCreator;

    public ProgramDispatcher(
            Data data,
            Reader reader,
            Writer writer,
            ObserverCreator observerCreator,
            ObservableCreator observableCreator) {
        this.data = data;
        this.reader = reader;
        this.writer = writer;
        this.observerCreator = observerCreator;
        this.observableCreator = observableCreator;
    }

    @Override
    public void readEntities(int entitiesCount) throws IOException {
        for (int i = 0; i < entitiesCount; i++) {
            String[] entitiesTokens = reader.readLine().split("\\s+");
            Observable observable = observableCreator.createObservable(entitiesTokens);
            data.addObservable(observable);
        }
    }

    @Override
    public void readInstitutions(int institutionsCount) throws IOException {
        for (int i = 0; i < institutionsCount; i++) {
            String[] institutionTokens = reader.readLine().split("\\s+");
            Observer observer = observerCreator.create(institutionTokens);
            data.addObserver(observer);
            data.subscribeObserver(observer);
        }
    }

    public void executeChange(String[] changesTokens) throws IllegalAccessException, InvocationTargetException {
        String id = changesTokens[0];
        String fieldName = changesTokens[1];
        String parameter = changesTokens[2];

        Observable observable = data.getObservable(id);
        String observableSimpleClass = observable.getClass().getSimpleName();

        Class<?> observableClass = observable.getClass();
        Method[] observableClassDeclaredMethods = observableClass.getDeclaredMethods();

        for (Method method : observableClassDeclaredMethods) {
            Setter setter = method.getAnnotation(Setter.class);
            if (setter != null && setter.fieldName().equals(fieldName)) {
                if (setter.fieldType().equals("int")) {
                    method.invoke(observable, Integer.valueOf(parameter));
                } else {
                    method.invoke(observable, parameter);
                }
            }
        }
    }

    @Override
    public void printChangeLog() {
        for (String observerId : this.data.getObservers()) {
            Observer observer = this.data.getObserver(observerId);
            List<String> observerChangeLog = observer.getChangeLog();

            String heading = String.format("%s: %s changes registered", observer.getName(), observerChangeLog.size());
            this.writer.writeLine(heading);

            for (String change : observerChangeLog) {
                this.writer.writeLine(change);
            }
        }
    }
}
