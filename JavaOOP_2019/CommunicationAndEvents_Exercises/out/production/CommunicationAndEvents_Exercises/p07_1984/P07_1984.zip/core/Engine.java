package core;

import interfaces.Data;
import interfaces.Dispatcher;
import interfaces.Reader;
import interfaces.Runnable;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class Engine implements Runnable {

    private Reader reader;
    private Data data;
    private Dispatcher dispatcher;

    public Engine(
            Reader reader,
            Data data,
            Dispatcher dispatcher) {
        this.reader = reader;
        this.dispatcher = dispatcher;
    }

    @Override
    public void run() throws IOException, InvocationTargetException, IllegalAccessException {
        String[] inputTokens = reader.readLine().split("\\s+");
        int entitiesCount = Integer.valueOf(inputTokens[0]);
        int institutionCount = Integer.valueOf(inputTokens[1]);
        int changesCount = Integer.valueOf(inputTokens[2]);

        this.dispatcher.readEntities(entitiesCount);
        this.dispatcher.readInstitutions(institutionCount);

        for (int i = 0; i < changesCount; i++) {
            inputTokens = reader.readLine().split("\\s+");
            this.dispatcher.executeChange(inputTokens);
        }

        this.dispatcher.printChangeLog();
    }
}
