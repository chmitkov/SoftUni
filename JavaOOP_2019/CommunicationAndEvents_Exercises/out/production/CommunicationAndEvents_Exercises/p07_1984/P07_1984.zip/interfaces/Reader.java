package interfaces;

import java.io.IOException;

public interface Reader {
    public String readLine() throws IOException;
}
