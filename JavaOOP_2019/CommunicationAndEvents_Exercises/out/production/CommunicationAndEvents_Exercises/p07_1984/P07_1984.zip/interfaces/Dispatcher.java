package interfaces;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public interface Dispatcher {
    public void readEntities(int entitiesCount) throws IOException;
    public void readInstitutions(int institutionsCount) throws IOException;
    public void executeChange(String[] changeTokens) throws IllegalAccessException, InvocationTargetException;
    public void printChangeLog();
}
