package interfaces;

import java.lang.reflect.Field;

public interface Event<T> {

    public Observable getSource();
    public Field getChangedField();
    public T getOldValue();
    public T getNewValue();
}
