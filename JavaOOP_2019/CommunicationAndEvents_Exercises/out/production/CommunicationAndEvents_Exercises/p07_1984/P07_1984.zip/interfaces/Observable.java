package interfaces;

import java.lang.reflect.Field;

public interface Observable extends Identifiable, Nameable {
    public <T> void triggerEvent(Field field, T oldValue, T newValue);
    public void registerObserver(Observer observer);
    public void removeObserver(Observer observer);
}
