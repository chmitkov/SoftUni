package interfaces;

public interface Nameable {
    public String getName();
}
