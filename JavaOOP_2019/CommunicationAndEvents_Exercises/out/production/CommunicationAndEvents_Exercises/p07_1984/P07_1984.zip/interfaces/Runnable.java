package interfaces;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public interface Runnable {
    public void run() throws IOException, InvocationTargetException, IllegalAccessException;
}
