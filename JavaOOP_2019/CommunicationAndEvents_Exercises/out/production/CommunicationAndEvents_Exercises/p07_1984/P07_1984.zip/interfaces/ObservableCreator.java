package interfaces;

public interface ObservableCreator {
    public Observable createObservable(String[] observableParameters);
}
