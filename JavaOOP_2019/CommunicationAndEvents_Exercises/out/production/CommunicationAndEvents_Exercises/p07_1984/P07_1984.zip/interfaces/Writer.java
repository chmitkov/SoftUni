package interfaces;

public interface Writer {
    public void writeLine(String message);
}
