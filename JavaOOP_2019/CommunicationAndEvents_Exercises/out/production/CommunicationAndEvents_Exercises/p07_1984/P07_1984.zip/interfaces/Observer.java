package interfaces;

import java.util.List;

public interface Observer extends Identifiable, Nameable {
    public void update(Event event);
    public List<String> getChangeLog();
}
