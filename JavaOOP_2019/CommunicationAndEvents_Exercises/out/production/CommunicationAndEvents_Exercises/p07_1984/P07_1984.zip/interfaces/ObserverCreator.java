package interfaces;

public interface ObserverCreator {
    public Observer create(String[] observerParameters);
}
