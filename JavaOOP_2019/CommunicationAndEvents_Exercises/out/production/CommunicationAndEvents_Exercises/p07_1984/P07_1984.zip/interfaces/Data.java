package interfaces;

import java.util.Set;

public interface Data {
    public void addObserver(Observer observer);
    public Observer getObserver(String id);
    public void addObservable(Observable observable);
    public Observable getObservable(String id);
    public void subscribeObserver(Observer observer);
    public Set<String> getObservers();
}
