package factories;

import interfaces.Observable;
import interfaces.ObservableCreator;
import models.Company;
import models.Employee;

public class ObservableFactory implements ObservableCreator {

    @Override
    public Observable createObservable(String[] observableParameters) {
        String type = observableParameters[0];
        String id = observableParameters[1];
        String name = observableParameters[2];

        switch (type) {
            case "Employee":
                int income = Integer.valueOf(observableParameters[3]);
                return new Employee(id, name, income);
            case "Company":
                int turnover = Integer.valueOf(observableParameters[3]);
                int revenue = Integer.valueOf(observableParameters[4]);
                return new Company(id, name, turnover, revenue);
            default:
                throw new IllegalArgumentException("Invalid arguments.");
        }
    }
}
