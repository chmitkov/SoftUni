package factories;

import interfaces.Observer;
import interfaces.ObserverCreator;
import models.Institution;

public class ObserverFactory implements ObserverCreator {

    @Override
    public Observer create(String[] observerParameters) {
        String id = observerParameters[1];
        String name = observerParameters[2];
        String[] subjects = new String[observerParameters.length - 3];
        for (int i = 3; i < observerParameters.length; i++) {
            subjects[i - 3] = observerParameters[i];
        }

        return new Institution(id, name, subjects);
    }
}
