package io;

import interfaces.Writer;

public class TerminalWriter implements Writer {

    @Override
    public void writeLine(String message) {
        System.out.println(message);
    }
}
