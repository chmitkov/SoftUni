import core.DataBase;
import core.Engine;
import core.ProgramDispatcher;
import factories.ObservableFactory;
import factories.ObserverFactory;
import interfaces.*;
import interfaces.Runnable;
import io.BufferedStreamReader;
import io.TerminalWriter;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class Main {

    public static void main(String[] args) {

        Data data = new DataBase();
        Reader reader = new BufferedStreamReader();
        Writer writer = new TerminalWriter();
        ObserverCreator observerCreator = new ObserverFactory();
        ObservableCreator observableCreator = new ObservableFactory();

        Dispatcher dispatcher = new ProgramDispatcher(data, reader, writer, observerCreator, observableCreator);
        Runnable engine = new Engine(reader, data, dispatcher);

        try {
            engine.run();
        } catch (IllegalAccessException | IOException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
