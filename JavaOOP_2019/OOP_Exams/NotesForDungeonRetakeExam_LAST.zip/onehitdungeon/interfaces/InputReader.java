package onehitdungeon.interfaces;

public interface InputReader {
    String readLine();
}
