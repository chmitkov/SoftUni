package onehitdungeon.interfaces;

public interface ArmorItem extends Item {
}
