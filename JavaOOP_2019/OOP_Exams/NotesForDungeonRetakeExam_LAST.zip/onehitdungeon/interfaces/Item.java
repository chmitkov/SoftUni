package onehitdungeon.interfaces;

public interface Item {
    Integer getBattlePower();

    Double getPriceForUpgrade();
}
