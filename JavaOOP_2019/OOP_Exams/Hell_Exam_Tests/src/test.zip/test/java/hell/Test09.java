package hell;

import org.junit.Test;

//Test09TestHeroInventoryAddRecipeItemItem
public class Test09 {



    @Test
    public void test(){

    }
}
