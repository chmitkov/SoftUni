package core.controllers;

import core.controllers.interfaces.FlightController;
import entities.AirportImpl;
import entities.interfaces.Airport;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class FlightManagerTest {

    private FlightController flightManager;
    private Airport airport;

    @Before
    public void before(){
      this.airport = Mockito.mock(AirportImpl.class);
      this.flightManager = new FlightManager(airport);
    }

    @Test
    public void testTakeOff(){

    }
}