package entities.items;

public class Toothbrush extends BaseItem {
    private static final int INIT_VALUE = 3;

    protected Toothbrush() {
        super(INIT_VALUE);
    }
}
