package entities.interfaces;

public interface Reader  {
    String readLine();
}
