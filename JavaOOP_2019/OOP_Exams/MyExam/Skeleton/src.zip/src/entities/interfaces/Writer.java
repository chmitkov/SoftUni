package entities.interfaces;

public interface Writer {
    void printLine(String text);
}
