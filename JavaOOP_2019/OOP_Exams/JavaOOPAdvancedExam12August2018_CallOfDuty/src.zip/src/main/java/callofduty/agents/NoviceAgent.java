package callofduty.agents;

import callofduty.interfaces.Mission;

public class NoviceAgent extends BaseAgent {

    public NoviceAgent(String id, String name, Double rating) {
        super(id, name, rating);
    }

    @Override
    public void completeMissions() {
        for (Mission mission : super.getAllMissions()) {
            super.setRating(super.getRating() + mission.getRating());
            mission.changeStatus();
        }
        super.addCompleteMissions(super.getAllMissions());
    }
}
