package callofduty.interfaces;

public interface Mission extends Identifiable, Rateable, Bountyable {
    public String printStatus();

    public Double getBounty();

    public String getId();

    public Double getRating();

    public boolean getStatus();

    public void changeStatus();
}
