package callofduty.agents;

import callofduty.missions.Mission;

public class NoviceAgent extends Agent {

    public NoviceAgent(String id, String name, Double rating) {
        super(id, name, rating);
    }

    @Override
    public void acceptMission(callofduty.interfaces.Mission mission) {
        super.acceptMission((Mission)mission);
    }

    @Override
    public void completeMissions() {
        for (Mission mission : super.getAllMissions()) {
            super.setRating(super.getRating() + mission.getRating());
            mission.changeStatus();
        }
        super.addCompleteMissions(super.getAllMissions());
    }
}
