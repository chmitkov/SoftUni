package panzer.models.Parts;

import panzer.contracts.HitPointsModifyingPart;

import java.math.BigDecimal;

public class EndurancePart extends BasePart implements HitPointsModifyingPart {

    private Integer hitPointsModifier;

    protected EndurancePart(String model, Double weight,
                            BigDecimal price, Integer hitPointsModifier) {
        super(model, weight, price);
        this.hitPointsModifier = hitPointsModifier;
    }

    public int getHitPointsModifier() {
        return this.hitPointsModifier;
    }
}
