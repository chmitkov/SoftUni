package entities.items;

public class Jewelery extends BaseItem {
    private static final int INIT_VALUE = 300;

    protected Jewelery() {
        super(INIT_VALUE);
    }
}
