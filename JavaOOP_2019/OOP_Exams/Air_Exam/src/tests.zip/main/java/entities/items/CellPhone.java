package entities.items;

public class CellPhone extends BaseItem {
    private static final int INIT_VALUE = 700;

    protected CellPhone() {
        super(INIT_VALUE);
    }
}
