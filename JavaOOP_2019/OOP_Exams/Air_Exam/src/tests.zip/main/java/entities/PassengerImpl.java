package entities;

import entities.interfaces.Bag;
import entities.interfaces.Passenger;

import java.util.List;

public class PassengerImpl implements Passenger {

    private String username;
    private List<Bag> bags;

    @Override
    public String getUsername() {
        return this.username;
    }

    @Override
    public List<Bag> getBags() {
        return this.bags;
    }
}
