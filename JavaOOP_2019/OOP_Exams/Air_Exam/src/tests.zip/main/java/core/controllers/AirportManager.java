package core.controllers;

import core.controllers.interfaces.AirportController;

import javax.naming.OperationNotSupportedException;

public class AirportManager implements AirportController {
   //TODO

    @Override
    public String registerPassenger(String username) throws OperationNotSupportedException {
        return null;
    }

    @Override
    public String registerBag(String username, Iterable<String> bagItems) {
        return null;
    }

    @Override
    public String registerTrip(String source, String destination, String planeType) {
        return null;
    }

    @Override
    public String checkIn(String username, String tripId, Iterable<Integer> bagIndices) {
        return null;
    }
}
