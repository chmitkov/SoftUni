package entities.items;

public class Colombian extends BaseItem {
    private static final int INIT_VALUE = 50000;

    protected Colombian() {
        super(INIT_VALUE);
    }
}
