package entities.items;

public class TravelKit extends BaseItem {
    private static final int INIT_VALUE = 30;

    protected TravelKit() {
        super(INIT_VALUE);
    }
}
