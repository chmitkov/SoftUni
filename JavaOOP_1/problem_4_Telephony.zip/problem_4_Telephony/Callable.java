package problem_4_Telephony;

public interface Callable {
    String callTo();
}
