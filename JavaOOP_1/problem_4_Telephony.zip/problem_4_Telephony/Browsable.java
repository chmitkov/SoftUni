package problem_4_Telephony;

public interface Browsable {
    String browseIn();
}
