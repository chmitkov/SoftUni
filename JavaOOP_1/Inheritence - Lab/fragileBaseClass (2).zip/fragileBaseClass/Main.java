package fragileBaseClass;

public class Main {
}
