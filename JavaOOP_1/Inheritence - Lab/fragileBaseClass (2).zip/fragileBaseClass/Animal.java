package fragileBaseClass;

import javafx.print.Collation;

import java.util.Collections;
import java.util.List;

public class Animal {
    protected List<Food> footEaten;

    public final void eat(Food food) {
        this.footEaten.add(food);
    }

    public final void eatAll(Food[] foods) {
        Collections.addAll(this.footEaten,foods);
    }
}
