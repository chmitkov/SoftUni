package fragileBaseClass;

public class Predator extends Animal {
}
